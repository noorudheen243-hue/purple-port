import{v as o}from"./index-d7QF-En7.js";/**
 * @license lucide-react v0.331.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=o("Play",[["polygon",{points:"5 3 19 12 5 21 5 3",key:"191637"}]]);export{e as P};
