import{ax as s}from"./index-1sOZeg-c.js";function e(o){const t=s(o);return t.setDate(1),t.setHours(0,0,0,0),t}export{e as s};
