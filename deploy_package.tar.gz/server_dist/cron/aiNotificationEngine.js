"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.initAIEngine = exports.runMoMFollowupScanner = exports.runPendingRequestCheck = exports.runAttendancePatternDetection = exports.runTaskDelayDetection = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const node_cron_1 = __importDefault(require("node-cron"));
const engine_1 = require("../modules/notifications/engine");
const date_fns_1 = require("date-fns");
// --- HELPERS ---
const getAIRule = (name) => __awaiter(void 0, void 0, void 0, function* () {
    return yield prisma_1.default.aINotificationRule.findUnique({
        where: { name }
    });
});
const createAlertLog = (userId_1, type_1, title_1, msg_1, reqAction_1, ...args_1) => __awaiter(void 0, [userId_1, type_1, title_1, msg_1, reqAction_1, ...args_1], void 0, function* (userId, type, title, msg, reqAction, level = 1) {
    return yield prisma_1.default.aIAlertLog.create({
        data: {
            user_id: userId,
            alert_type: type,
            title,
            message: msg,
            suggestion: reqAction,
            escalation_level: level
        }
    });
});
const notifyAdminOrManager = (managerId, title, msg, category) => __awaiter(void 0, void 0, void 0, function* () {
    if (managerId) {
        yield (0, engine_1.sendSmartNotification)(managerId, category, title, msg, '/dashboard');
    }
    else {
        const admins = yield prisma_1.default.user.findMany({ where: { role: 'ADMIN' }, select: { id: true } });
        for (const admin of admins) {
            yield (0, engine_1.sendSmartNotification)(admin.id, category, title, msg, '/dashboard');
        }
    }
});
const formatTemplate = (template, data) => {
    let result = template;
    for (const [key, value] of Object.entries(data)) {
        result = result.replace(new RegExp(`\\{${key}\\}`, 'g'), String(value));
    }
    return result;
};
// --- CORE AI LOGIC ---
const runTaskDelayDetection = () => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c;
    console.log("[AI Engine] Scanning for Task Delays...");
    const now = new Date();
    // Level 1 Rule
    const ruleL1 = yield getAIRule('Task Overdue Level 1');
    const ruleL2 = yield getAIRule('Task Overdue Level 2 (Manager)');
    if (!(ruleL1 === null || ruleL1 === void 0 ? void 0 : ruleL1.is_active) && !(ruleL2 === null || ruleL2 === void 0 ? void 0 : ruleL2.is_active))
        return;
    const delayedTasks = yield prisma_1.default.task.findMany({
        where: {
            status: { notIn: ['COMPLETED', 'CANCELLED'] },
            due_date: { lt: now }
        },
        include: { assignee: { include: { staffProfile: true } } }
    });
    for (const task of delayedTasks) {
        if (!task.assignee_id)
            continue;
        const overdueDays = Math.floor((now.getTime() - new Date(task.due_date).getTime()) / (1000 * 3600 * 24));
        const configL1 = JSON.parse((ruleL1 === null || ruleL1 === void 0 ? void 0 : ruleL1.config_json) || '{"threshold_days":1}');
        const configL2 = JSON.parse((ruleL2 === null || ruleL2 === void 0 ? void 0 : ruleL2.config_json) || '{"threshold_days":3}');
        if ((ruleL2 === null || ruleL2 === void 0 ? void 0 : ruleL2.is_active) && overdueDays >= configL2.threshold_days) {
            const managerId = ((_b = (_a = task.assignee) === null || _a === void 0 ? void 0 : _a.staffProfile) === null || _b === void 0 ? void 0 : _b.reporting_manager_id) || null;
            const msg = formatTemplate(ruleL2.message_template, {
                task_name: task.title,
                staff_name: (_c = task.assignee) === null || _c === void 0 ? void 0 : _c.full_name,
                delay_days: overdueDays
            });
            yield createAlertLog(task.assignee_id, 'CRITICAL', 'Task Escalation', msg, 'Intervention recommended.', 3);
            yield notifyAdminOrManager(managerId, 'Task Escalation', msg, 'TASKS');
            yield (0, engine_1.sendSmartNotification)(task.assignee_id, 'TASKS', 'Critical Delay', msg, `/dashboard/tasks/${task.id}`);
        }
        else if ((ruleL1 === null || ruleL1 === void 0 ? void 0 : ruleL1.is_active) && overdueDays >= configL1.threshold_days) {
            const msg = formatTemplate(ruleL1.message_template, { task_name: task.title });
            yield createAlertLog(task.assignee_id, 'WARNING', 'Task Delay', msg, 'Prioritize completion.', 1);
            yield (0, engine_1.sendSmartNotification)(task.assignee_id, 'TASKS', 'Task Reminder', msg, `/dashboard/tasks/${task.id}`);
        }
    }
});
exports.runTaskDelayDetection = runTaskDelayDetection;
const runAttendancePatternDetection = () => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    console.log("[AI Engine] Scanning Attendance Patterns...");
    const rule = yield getAIRule('Attendance Pattern Warning');
    if (!rule || !rule.is_active)
        return;
    const config = JSON.parse(rule.config_json || '{"threshold_count":3, "period_days":7}');
    const periodStart = (0, date_fns_1.subDays)(new Date(), config.period_days);
    // Simplified late logic
    const records = yield prisma_1.default.attendanceRecord.findMany({
        where: { date: { gte: periodStart }, status: 'PRESENT', check_in: { not: null } }
    });
    const userLateCounts = new Map();
    records.forEach(r => {
        const time = new Date(r.check_in);
        if (time.getHours() > 10 || (time.getHours() === 10 && time.getMinutes() > 15)) {
            userLateCounts.set(r.user_id, (userLateCounts.get(r.user_id) || 0) + 1);
        }
    });
    for (const [userId, count] of userLateCounts.entries()) {
        if (count >= config.threshold_count) {
            const user = yield prisma_1.default.user.findUnique({ where: { id: userId }, include: { staffProfile: true } });
            if (!user)
                continue;
            const msg = formatTemplate(rule.message_template, { late_count: count });
            yield createAlertLog(userId, 'WARNING', 'Trend Detected', msg, 'Review punctuality.', 2);
            yield (0, engine_1.sendSmartNotification)(userId, 'ATTENDANCE', 'Pattern Alert', msg, '/dashboard/attendance');
            yield notifyAdminOrManager(((_a = user.staffProfile) === null || _a === void 0 ? void 0 : _a.reporting_manager_id) || null, 'Late Trend', `${user.full_name} was late ${count} times recently.`, 'ATTENDANCE');
        }
    }
});
exports.runAttendancePatternDetection = runAttendancePatternDetection;
const runPendingRequestCheck = () => __awaiter(void 0, void 0, void 0, function* () {
    console.log("[AI Engine] Scanning Pending Requests...");
    const rule = yield getAIRule('Request Pending Alert');
    if (!rule || !rule.is_active)
        return;
    const config = JSON.parse(rule.config_json || '{"threshold_hours":24}');
    const pendingLeaves = yield prisma_1.default.leaveRequest.findMany({
        where: { status: 'PENDING', createdAt: { lt: (0, date_fns_1.subDays)(new Date(), config.threshold_hours / 24) } },
        include: { user: true }
    });
    for (const req of pendingLeaves) {
        const msg = formatTemplate(rule.message_template, { staff_name: req.user.full_name });
        // Notify Admins about the pending request
        yield notifyAdminOrManager(null, 'Pending Leave Approval', msg, 'REQUESTS');
    }
});
exports.runPendingRequestCheck = runPendingRequestCheck;
const runMoMFollowupScanner = () => __awaiter(void 0, void 0, void 0, function* () {
    console.log("[AI Engine] Scanning MoM Expiry...");
    const rule = yield getAIRule('MoM Followup Alert');
    if (!rule || !rule.is_active)
        return;
    const config = JSON.parse(rule.config_json || '{"threshold_hours":24}');
    const meetings = yield prisma_1.default.meeting.findMany({
        where: {
            status: { not: 'CANCELLED' },
            mom: null,
            date: { lte: new Date() }
        },
        include: { organizer: true }
    });
    for (const mtg of meetings) {
        const mtgDateTime = new Date(`${mtg.date.toISOString().slice(0, 10)}T${mtg.time}`);
        if ((0, date_fns_1.differenceInHours)(new Date(), mtgDateTime) >= config.threshold_hours) {
            const msg = formatTemplate(rule.message_template, { meeting_title: mtg.title });
            yield createAlertLog(mtg.organizer_id, 'WARNING', 'MoM Missing', msg, 'Submit MoM immediately.', 2);
            yield (0, engine_1.sendSmartNotification)(mtg.organizer_id, 'MEETINGS', 'MoM Expired', msg, '/dashboard/meetings');
        }
    }
});
exports.runMoMFollowupScanner = runMoMFollowupScanner;
const initAIEngine = () => {
    // Every 5 minutes for prompt local feedback
    node_cron_1.default.schedule('*/5 * * * *', () => __awaiter(void 0, void 0, void 0, function* () {
        try {
            yield (0, exports.runTaskDelayDetection)();
            yield (0, exports.runAttendancePatternDetection)();
            yield (0, exports.runPendingRequestCheck)();
            yield (0, exports.runMoMFollowupScanner)();
        }
        catch (e) {
            console.error("[AI Engine] Fatal:", e);
        }
    }));
    console.log('🤖 AI Smart Notification Engine v2 Online.');
};
exports.initAIEngine = initAIEngine;
