"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MetaAdsService = void 0;
const prisma_1 = __importDefault(require("../../../utils/prisma"));
const axios_1 = __importDefault(require("axios"));
const date_fns_1 = require("date-fns");
const META_GRAPH_URL = 'https://graph.facebook.com/v21.0';
class MetaAdsService {
    /**
     * Helper to fetch the valid access token for a given marketing account.
     */
    getValidToken(accountId) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const account = yield prisma_1.default.marketingAccount.findFirst({
                where: { externalAccountId: accountId, platform: 'meta' },
                include: { metaToken: true }
            });
            if (!account) {
                throw new Error(`Meta Ads: No marketing account found for ID ${accountId}`);
            }
            // Prioritize the token from the linked MetaToken record (Global Profile)
            if ((_a = account.metaToken) === null || _a === void 0 ? void 0 : _a.access_token) {
                return account.metaToken.access_token;
            }
            if (!account.accessToken) {
                throw new Error(`Meta Ads: No access token found for account ${accountId}`);
            }
            return account.accessToken;
        });
    }
    /**
     * Internal helper to fetch all pages from a Meta Graph API endpoint.
     */
    fetchAll(url, params) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a, _b, _c, _d;
            let results = [];
            let currentUrl = url;
            let currentParams = Object.assign(Object.assign({}, params), { limit: 100 });
            try {
                while (currentUrl) {
                    const response = yield axios_1.default.get(currentUrl, { params: currentParams });
                    const data = ((_a = response.data) === null || _a === void 0 ? void 0 : _a.data) || [];
                    results = [...results, ...data];
                    currentUrl = ((_c = (_b = response.data) === null || _b === void 0 ? void 0 : _b.paging) === null || _c === void 0 ? void 0 : _c.next) || null;
                    // Meta's nextUrl is a full URL with params already encoded
                    currentParams = {};
                }
                return results;
            }
            catch (error) {
                console.error(`[MetaAds] fetchAll error for ${url}:`, ((_d = error.response) === null || _d === void 0 ? void 0 : _d.data) || error.message);
                if (results.length > 0)
                    return results;
                throw error;
            }
        });
    }
    /**
     * Fetch all Business Manager accounts/Ad Accounts the user has access to.
     */
    fetchAccounts(systemUserId, clientId) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a, _b, _c, _d;
            let userToken = 'mock-long-lived-meta-token';
            if (clientId) {
                const acc = yield prisma_1.default.marketingAccount.findFirst({
                    where: { clientId, platform: 'meta' },
                    include: { metaToken: true }
                });
                if ((_a = acc === null || acc === void 0 ? void 0 : acc.metaToken) === null || _a === void 0 ? void 0 : _a.access_token) {
                    userToken = acc.metaToken.access_token;
                }
                else if (acc === null || acc === void 0 ? void 0 : acc.accessToken) {
                    userToken = acc.accessToken;
                }
            }
            if (userToken === 'mock-long-lived-meta-token') {
                const user = yield prisma_1.default.user.findUnique({
                    where: { id: systemUserId },
                    include: { metaTokens: { where: { isActive: true }, take: 1 } }
                });
                userToken = ((_c = (_b = user === null || user === void 0 ? void 0 : user.metaTokens) === null || _b === void 0 ? void 0 : _b[0]) === null || _c === void 0 ? void 0 : _c.access_token) || userToken;
            }
            // Local Sandbox Mock
            if (userToken.startsWith('mock')) {
                return [{ id: 'act_123456789', name: 'Antigravity Test Ad Account', account_status: 1 }];
            }
            try {
                const response = yield axios_1.default.get(`${META_GRAPH_URL}/me/adaccounts`, {
                    params: {
                        access_token: userToken,
                        fields: 'name,account_status,currency,timezone_name'
                    }
                });
                return response.data.data;
            }
            catch (error) {
                console.error('Meta API fetchAccounts error:', ((_d = error.response) === null || _d === void 0 ? void 0 : _d.data) || error.message);
                throw new Error('Failed to fetch Meta Ad Accounts');
            }
        });
    }
    ensureActPrefix(id) {
        if (!id)
            return id;
        return id.startsWith('act_') ? id : `act_${id}`;
    }
    /**
     * Fetch all campaigns under a specific Ad Account.
     */
    fetchCampaigns(accountId) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const token = yield this.getValidToken(accountId);
            const formattedAccountId = this.ensureActPrefix(accountId);
            console.log(`[MetaAds] fetchCampaigns called for account: ${formattedAccountId}`);
            if (token.startsWith('mock')) {
                return [
                    { id: 'camp_meta_1', name: 'IG Awareness Q1', status: 'ACTIVE', objective: 'BRAND_AWARENESS' },
                    { id: 'camp_meta_2', name: 'FB Lead Gen - Real Estate', status: 'ACTIVE', objective: 'LEAD_GENERATION' }
                ];
            }
            try {
                const campaigns = yield this.fetchAll(`${META_GRAPH_URL}/${formattedAccountId}/campaigns`, {
                    access_token: token,
                    fields: 'id,name,status,effective_status,objective',
                    effective_status: JSON.stringify(['ACTIVE', 'PAUSED', 'DELETED', 'ARCHIVED'])
                });
                console.log(`[MetaAds] fetchCampaigns result for ${formattedAccountId}: ${campaigns.length} campaigns.`);
                return campaigns;
            }
            catch (error) {
                console.error(`[MetaAds] fetchCampaigns error for ${formattedAccountId}:`, ((_a = error.response) === null || _a === void 0 ? void 0 : _a.data) || error.message);
                return [];
            }
        });
    }
    /**
     * Fetch daily insights (metrics) for a specific campaign over a date range.
     */
    fetchMetrics(campaignId, accountId, from, to) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const token = yield this.getValidToken(accountId);
            const formattedAccountId = this.ensureActPrefix(accountId);
            // Format dates as YYYY-MM-DD required by Meta Ads API
            const timeRange = JSON.stringify({
                since: (0, date_fns_1.format)(from, 'yyyy-MM-dd'),
                until: (0, date_fns_1.format)(to, 'yyyy-MM-dd')
            });
            if (token.startsWith('mock')) {
                // Generate some random seeded data based on the requested days
                const mockData = [];
                let currentDate = new Date(from);
                while (currentDate <= to) {
                    mockData.push({
                        date_start: (0, date_fns_1.format)(currentDate, 'yyyy-MM-dd'),
                        impressions: Math.floor(Math.random() * 5000),
                        reach: Math.floor(Math.random() * 4000), // Mock reach
                        clicks: Math.floor(Math.random() * 200),
                        spend: (Math.random() * 1000).toFixed(2),
                        results: Math.floor(Math.random() * 20), // Mock results
                        actions: [{ action_type: 'lead', value: Math.floor(Math.random() * 10) }]
                    });
                    currentDate.setDate(currentDate.getDate() + 1);
                }
                return mockData;
            }
            try {
                const rawData = yield this.fetchAll(`${META_GRAPH_URL}/${campaignId}/insights`, {
                    access_token: token,
                    time_range: timeRange,
                    time_increment: 1, // Daily breakdown
                    fields: 'impressions,reach,clicks,spend,actions,cpc,cpm,ctr'
                });
                // Map actions array to flat results/conversions
                return rawData.map((day) => {
                    let totalResults = 0;
                    let totalConversions = 0;
                    let maxMessages = 0;
                    let maxLeads = 0;
                    let maxPurchases = 0;
                    if (day.actions && Array.isArray(day.actions)) {
                        for (const action of day.actions) {
                            const val = parseInt(action.value || '0', 10);
                            const type = action.action_type;
                            if (type.includes('lead'))
                                maxLeads = Math.max(maxLeads, val);
                            if (type.includes('messaging_conversation_started') || type.includes('onsite_conversion.messaging_conversation_started_7d')) {
                                maxMessages = Math.max(maxMessages, val);
                            }
                            if (type.includes('purchase'))
                                maxPurchases = Math.max(maxPurchases, val);
                        }
                        // Combined results
                        totalResults = maxLeads + maxMessages + maxPurchases;
                        totalConversions = totalResults;
                    }
                    return Object.assign(Object.assign({}, day), { results: totalResults, conversions: totalConversions, conversations: maxMessages });
                });
            }
            catch (error) {
                console.error(`Meta API fetchMetrics error for campaign ${campaignId}:`, ((_a = error.response) === null || _a === void 0 ? void 0 : _a.data) || error.message);
                return [];
            }
        });
    }
    /**
     * Fetch daily insights (metrics) for an entire account broken down by campaign over a date range.
     * This avoids making N API calls for N campaigns.
     */
    fetchAccountMetricsByCampaign(accountId, from, to) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const token = yield this.getValidToken(accountId);
            const formattedAccountId = this.ensureActPrefix(accountId);
            // Format dates as YYYY-MM-DD required by Meta Ads API
            const timeRange = JSON.stringify({
                since: (0, date_fns_1.format)(from, 'yyyy-MM-dd'),
                until: (0, date_fns_1.format)(to, 'yyyy-MM-dd')
            });
            if (token.startsWith('mock')) {
                // Wait, we can generate a mock list, but mostly keeping it empty or a single entry for sandbox since it's already tested
                return [];
            }
            try {
                const rawData = yield this.fetchAll(`${META_GRAPH_URL}/${formattedAccountId}/insights`, {
                    access_token: token,
                    level: 'campaign',
                    time_range: timeRange,
                    time_increment: 1, // Daily breakdown
                    fields: 'campaign_id,campaign_name,impressions,reach,clicks,spend,actions,cpc,cpm,ctr'
                });
                // Map actions array to flat results/conversions
                return rawData.map((day) => {
                    let totalResults = 0;
                    let totalConversions = 0;
                    let maxMessages = 0;
                    let maxLeads = 0;
                    let maxPurchases = 0;
                    if (day.actions && Array.isArray(day.actions)) {
                        for (const action of day.actions) {
                            const val = parseInt(action.value || '0', 10);
                            const type = action.action_type;
                            if (type.includes('lead'))
                                maxLeads = Math.max(maxLeads, val);
                            if (type.includes('messaging_conversation_started') || type.includes('onsite_conversion.messaging_conversation_started_7d')) {
                                maxMessages = Math.max(maxMessages, val);
                            }
                            if (type.includes('purchase'))
                                maxPurchases = Math.max(maxPurchases, val);
                        }
                        totalResults = maxLeads + maxMessages + maxPurchases;
                        totalConversions = totalResults;
                    }
                    return Object.assign(Object.assign({}, day), { results: totalResults, conversions: totalConversions, conversations: maxMessages });
                });
            }
            catch (error) {
                console.error(`Meta API fetchAccountMetricsByCampaign error for account ${formattedAccountId}:`, ((_a = error.response) === null || _a === void 0 ? void 0 : _a.data) || error.message);
                return [];
            }
        });
    }
    // ==========================================
    // META ADS MANAGER EXTENSIONS
    // ==========================================
    /**
     * Fetch deep campaign details (including daily budgets, spend)
     */
    fetchCampaignsDetailed(accountId) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a, _b, _c, _d;
            const token = yield this.getValidToken(accountId);
            const formattedAccountId = this.ensureActPrefix(accountId);
            if (token.startsWith('mock')) {
                return [
                    { id: 'camp_meta_1', name: 'IG Awareness Q1', status: 'ACTIVE', objective: 'OUTCOME_AWARENESS', daily_budget: 100000, start_time: new Date().toISOString() },
                    { id: 'camp_meta_2', name: 'FB Lead Gen - Real Estate', status: 'PAUSED', objective: 'OUTCOME_LEADS', daily_budget: 500000, start_time: new Date().toISOString() }
                ];
            }
            try {
                return yield this.fetchAll(`${META_GRAPH_URL}/${formattedAccountId}/campaigns`, {
                    access_token: token,
                    fields: 'id,name,status,effective_status,objective,daily_budget,lifetime_budget,start_time,stop_time',
                    effective_status: JSON.stringify(['ACTIVE', 'PAUSED', 'DELETED', 'ARCHIVED'])
                });
            }
            catch (error) {
                console.error(`fetchCampaignsDetailed error:`, ((_a = error.response) === null || _a === void 0 ? void 0 : _a.data) || error.message);
                throw new Error(`Failed to fetch campaigns: ${((_d = (_c = (_b = error.response) === null || _b === void 0 ? void 0 : _b.data) === null || _c === void 0 ? void 0 : _c.error) === null || _d === void 0 ? void 0 : _d.message) || error.message}`);
            }
        });
    }
    /**
     * Fetch Ad Sets for a campaign
     */
    fetchAdSets(campaignId, accountId) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            const token = yield this.getValidToken(accountId);
            if (token.startsWith('mock'))
                return [{ id: 'adset_1', name: 'Broad Audience 18-65', status: 'ACTIVE', daily_budget: 50000, targeting: {} }];
            try {
                const response = yield axios_1.default.get(`${META_GRAPH_URL}/${campaignId}/adsets`, {
                    params: {
                        access_token: token,
                        fields: 'id,name,status,daily_budget,lifetime_budget,start_time,end_time,targeting,promoted_object,billing_event,optimization_goal'
                    }
                });
                return ((_a = response.data) === null || _a === void 0 ? void 0 : _a.data) || [];
            }
            catch (error) {
                console.error(`fetchAdSets error:`, ((_b = error.response) === null || _b === void 0 ? void 0 : _b.data) || error.message);
                throw error;
            }
        });
    }
    /**
     * Fetch Ads for an Ad Set
     */
    fetchAds(adSetId, accountId) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            const token = yield this.getValidToken(accountId);
            if (token.startsWith('mock'))
                return [{ id: 'ad_1', name: 'Static Image Ad - House 1', status: 'ACTIVE', creative: { id: 'creative_1' } }];
            try {
                const response = yield axios_1.default.get(`${META_GRAPH_URL}/${adSetId}/ads`, {
                    params: {
                        access_token: token,
                        fields: 'id,name,status,creative{id,name,thumbnail_url}'
                    }
                });
                return ((_a = response.data) === null || _a === void 0 ? void 0 : _a.data) || [];
            }
            catch (error) {
                console.error(`fetchAds error:`, ((_b = error.response) === null || _b === void 0 ? void 0 : _b.data) || error.message);
                throw error;
            }
        });
    }
    /**
     * Create a new Campaign
     */
    createCampaign(accountId, data) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a, _b, _c, _d;
            const token = yield this.getValidToken(accountId);
            const formattedAccountId = this.ensureActPrefix(accountId);
            if (token.startsWith('mock'))
                return Object.assign({ id: `camp_mock_${Date.now()}` }, data);
            try {
                const response = yield axios_1.default.post(`${META_GRAPH_URL}/${formattedAccountId}/campaigns`, {
                    name: data.name,
                    objective: data.objective,
                    status: data.status || 'PAUSED',
                    special_ad_categories: [], // Empty for regular ads
                    access_token: token
                });
                return response.data;
            }
            catch (error) {
                console.error(`createCampaign error:`, ((_a = error.response) === null || _a === void 0 ? void 0 : _a.data) || error.message);
                throw new Error(`Campaign Creation Failed: ${((_d = (_c = (_b = error.response) === null || _b === void 0 ? void 0 : _b.data) === null || _c === void 0 ? void 0 : _c.error) === null || _d === void 0 ? void 0 : _d.message) || error.message}`);
            }
        });
    }
    /**
     * Create a new Ad Set
     */
    createAdSet(accountId, data) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a, _b, _c, _d, _e;
            const token = yield this.getValidToken(accountId);
            const formattedAccountId = this.ensureActPrefix(accountId);
            if (token.startsWith('mock'))
                return Object.assign({ id: `adset_mock_${Date.now()}` }, data);
            try {
                const payload = Object.assign(Object.assign({}, data), { access_token: token });
                const response = yield axios_1.default.post(`${META_GRAPH_URL}/${formattedAccountId}/adsets`, payload);
                return response.data;
            }
            catch (error) {
                console.error(`createAdSet error:`, ((_b = (_a = error.response) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.error) || error.message);
                throw new Error(`Ad Set Creation Failed: ${((_e = (_d = (_c = error.response) === null || _c === void 0 ? void 0 : _c.data) === null || _d === void 0 ? void 0 : _d.error) === null || _e === void 0 ? void 0 : _e.message) || error.message}`);
            }
        });
    }
    /**
     * Update Object Status (Pause/Activate)
     */
    updateStatus(objectId, accountId, status) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a, _b, _c, _d;
            const token = yield this.getValidToken(accountId);
            if (token.startsWith('mock'))
                return { success: true };
            try {
                const response = yield axios_1.default.post(`${META_GRAPH_URL}/${objectId}`, {
                    status,
                    access_token: token
                });
                return response.data;
            }
            catch (error) {
                console.error(`updateStatus error:`, ((_a = error.response) === null || _a === void 0 ? void 0 : _a.data) || error.message);
                throw new Error(`Status Update Failed: ${((_d = (_c = (_b = error.response) === null || _b === void 0 ? void 0 : _b.data) === null || _c === void 0 ? void 0 : _c.error) === null || _d === void 0 ? void 0 : _d.message) || error.message}`);
            }
        });
    }
}
exports.MetaAdsService = MetaAdsService;
