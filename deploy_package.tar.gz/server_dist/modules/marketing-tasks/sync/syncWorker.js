"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarketingSyncWorker = void 0;
const prisma_1 = __importDefault(require("../../../utils/prisma"));
const marketingNormalizer_1 = require("../normalizer/marketingNormalizer");
const metaAdsService_1 = require("../services/metaAdsService");
const googleAdsService_1 = require("../services/googleAdsService");
const metaLeadsService_1 = require("../services/metaLeadsService");
const metaService = new metaAdsService_1.MetaAdsService();
const googleService = new googleAdsService_1.GoogleAdsService();
const metaLeadsService = new metaLeadsService_1.MetaLeadsService();
class MarketingSyncWorker {
    /**
     * Syncs metrics for a specific platform and campaign within a date range
     */
    static syncCampaignMetrics(campaignId, accountId, platform, from, to) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let externalData = [];
                // Get the external ID from the DB record
                const campRecord = yield prisma_1.default.marketingCampaign.findUnique({
                    where: { id: campaignId }
                });
                if (!campRecord) {
                    console.warn(`Campaign ${campaignId} not found in DB. Skipping sync.`);
                    return;
                }
                const externalId = campRecord.externalCampaignId;
                if (platform === 'meta') {
                    externalData = yield metaService.fetchMetrics(externalId, accountId, from, to);
                }
                else if (platform === 'google') {
                    externalData = yield googleService.fetchMetrics(externalId, accountId, from, to);
                }
                else {
                    throw new Error(`Unsupported platform: ${platform}`);
                }
                for (const raw of externalData) {
                    yield this.upsertNormalizedMetric(campaignId, marketingNormalizer_1.MarketingDataNormalizer.normalizeMetric(raw));
                }
            }
            catch (error) {
                console.error(`Error syncing metrics for campaign ${campaignId} on ${platform}`, error);
                throw error;
            }
        });
    }
    static upsertNormalizedMetric(campaignId, normalized) {
        return __awaiter(this, void 0, void 0, function* () {
            if (isNaN(normalized.date.getTime())) {
                console.warn(`Skipping invalid date for campaign ${campaignId}`);
                return;
            }
            const gte = new Date(normalized.date);
            gte.setHours(0, 0, 0, 0);
            const lt = new Date(normalized.date);
            lt.setHours(23, 59, 59, 999);
            const existing = yield prisma_1.default.marketingMetric.findFirst({
                where: {
                    campaignId: campaignId,
                    date: {
                        gte: gte,
                        lt: lt
                    }
                }
            });
            if (existing) {
                yield prisma_1.default.marketingMetric.update({
                    where: { id: existing.id },
                    data: {
                        impressions: normalized.impressions,
                        clicks: normalized.clicks,
                        spend: normalized.spend,
                        conversions: normalized.conversions,
                        reach: normalized.reach,
                        results: normalized.results,
                        conversations: normalized.conversations,
                        ctr: normalized.ctr,
                        cpc: normalized.cpc,
                        cpm: normalized.cpm
                    }
                });
            }
            else {
                yield prisma_1.default.marketingMetric.create({
                    data: {
                        campaignId: campaignId,
                        date: normalized.date,
                        impressions: normalized.impressions,
                        clicks: normalized.clicks,
                        spend: normalized.spend,
                        conversions: normalized.conversions,
                        reach: normalized.reach,
                        results: normalized.results,
                        conversations: normalized.conversations,
                        ctr: normalized.ctr,
                        cpc: normalized.cpc,
                        cpm: normalized.cpm
                    }
                });
            }
        });
    }
    /**
     * Main entry point for cron job to sync all active campaigns
     * @param daysBack - Number of days of history to sync. Defaults to 2 (yesterday and today).
     */
    static syncAllActiveCampaigns() {
        return __awaiter(this, arguments, void 0, function* (daysBack = 2) {
            const log = yield prisma_1.default.marketingSyncLog.create({
                data: {
                    platform: 'ALL',
                    status: 'IN_PROGRESS',
                }
            });
            try {
                const today = new Date();
                const startDate = new Date(today);
                startDate.setDate(startDate.getDate() - (daysBack - 1)); // -1 because today is inclusive
                console.log(`[SyncWorker] Starting sync for the last ${daysBack} day(s) (from: ${startDate.toISOString().split('T')[0]})`);
                // Step 1: Discover New Campaigns for all linked accounts
                const allAccounts = yield prisma_1.default.marketingAccount.findMany({
                    where: {
                        OR: [
                            { accessToken: { not: null } },
                            { metaTokenId: { not: null } }
                        ]
                    }
                });
                console.log(`[SyncWorker] Found ${allAccounts.length} account(s) with tokens to sync:`, allAccounts.map((a) => `${a.platform}:${a.externalAccountId}`));
                for (const acc of allAccounts) {
                    try {
                        let externalCampaigns = [];
                        if (acc.platform === 'meta') {
                            // Reset all campaigns for this account to prevent ghost ACTIVE statuses
                            yield prisma_1.default.marketingCampaign.updateMany({
                                where: { platform: 'meta', clientId: acc.clientId },
                                data: { status: 'UNKNOWN' }
                            });
                            // Purge all old/duplicate metrics in the targeted sync window to guarantee 100% fresh parity
                            yield prisma_1.default.marketingMetric.deleteMany({
                                where: {
                                    campaign: { platform: 'meta', clientId: acc.clientId },
                                    date: { gte: startDate }
                                }
                            });
                            externalCampaigns = yield metaService.fetchCampaigns(acc.externalAccountId);
                        }
                        else if (acc.platform === 'google') {
                            yield prisma_1.default.marketingCampaign.updateMany({
                                where: { platform: 'google', clientId: acc.clientId },
                                data: { status: 'UNKNOWN' }
                            });
                            externalCampaigns = yield googleService.fetchCampaigns(acc.externalAccountId);
                        }
                        for (const ext of externalCampaigns) {
                            const campId = ext.id.toString();
                            const existing = yield prisma_1.default.marketingCampaign.findFirst({
                                where: { externalCampaignId: campId, platform: acc.platform }
                            });
                            if (!existing) {
                                yield prisma_1.default.marketingCampaign.create({
                                    data: {
                                        clientId: acc.clientId,
                                        platform: acc.platform,
                                        externalCampaignId: campId,
                                        name: ext.name,
                                        status: ext.effective_status || ext.status || 'UNKNOWN',
                                        objective: ext.objective || 'UNKNOWN'
                                    }
                                });
                            }
                            else {
                                // Update name/status if changed
                                yield prisma_1.default.marketingCampaign.update({
                                    where: { id: existing.id },
                                    data: {
                                        name: ext.name,
                                        status: ext.effective_status || ext.status || 'UNKNOWN'
                                    }
                                });
                            }
                        }
                    }
                    catch (discErr) {
                        console.error(`Discovery failed for account ${acc.externalAccountId}:`, discErr);
                    }
                }
                // Step 2: Sync Metrics
                let successCount = 0;
                for (const acc of allAccounts) {
                    // Determine if we process it with bulk or per-campaign
                    if (acc.platform === 'meta') {
                        try {
                            console.log(`[SyncWorker] Fetching bulk metrics for Meta account: ${acc.externalAccountId}`);
                            // Chunk fetching month by month to prevent OOM
                            let currentStart = new Date(startDate);
                            let finalEnd = new Date(today);
                            while (currentStart <= finalEnd) {
                                let currentEnd = new Date(currentStart);
                                currentEnd.setMonth(currentEnd.getMonth() + 1);
                                if (currentEnd > finalEnd)
                                    currentEnd = finalEnd;
                                console.log(`[SyncWorker] Fetching chunk: ${currentStart.toISOString()} to ${currentEnd.toISOString()}`);
                                const accountMetrics = yield metaService.fetchAccountMetricsByCampaign(acc.externalAccountId, currentStart, currentEnd);
                                // Group by campaign_id
                                const metricsByCampaign = new Map();
                                for (const row of accountMetrics) {
                                    if (!metricsByCampaign.has(row.campaign_id)) {
                                        metricsByCampaign.set(row.campaign_id, []);
                                    }
                                    metricsByCampaign.get(row.campaign_id).push(row);
                                }
                                for (const [extCampaignId, rows] of metricsByCampaign.entries()) {
                                    let campRecord = yield prisma_1.default.marketingCampaign.findFirst({
                                        where: { externalCampaignId: extCampaignId, platform: 'meta' }
                                    });
                                    if (!campRecord) {
                                        campRecord = yield prisma_1.default.marketingCampaign.create({
                                            data: {
                                                clientId: acc.clientId,
                                                platform: acc.platform,
                                                externalCampaignId: extCampaignId,
                                                name: rows[0].campaign_name || 'Unknown Campaign',
                                                status: 'UNKNOWN',
                                                objective: 'UNKNOWN'
                                            }
                                        });
                                    }
                                    // Batch database writes to prevent SQLite locks
                                    for (let i = 0; i < rows.length; i++) {
                                        yield this.upsertNormalizedMetric(campRecord.id.toString(), marketingNormalizer_1.MarketingDataNormalizer.normalizeMetric(rows[i]));
                                        // Yield thread every 50 records to prevent SQLite locking
                                        if (i % 50 === 0)
                                            yield new Promise(resolve => setTimeout(resolve, 5));
                                    }
                                    successCount++;
                                }
                                // Advance the exact offset
                                currentStart = new Date(currentEnd);
                                currentStart.setDate(currentStart.getDate() + 1);
                            }
                        }
                        catch (err) {
                            console.error(`Failed bulk sync for Meta account ${acc.externalAccountId}`, err);
                        }
                    }
                    else if (acc.platform === 'google') {
                        // Sync Per-Campaign for Google
                        const targetGoogleCampaigns = yield prisma_1.default.marketingCampaign.findMany({
                            where: {
                                clientId: acc.clientId,
                                platform: 'google',
                                status: { in: ['ACTIVE', 'ENABLED', 'PAUSED', 'ARCHIVED'] }
                            }
                        });
                        for (const camp of targetGoogleCampaigns) {
                            try {
                                yield this.syncCampaignMetrics(camp.id.toString(), acc.externalAccountId, camp.platform, startDate, today);
                                successCount++;
                            }
                            catch (err) {
                                console.error(`Failed to sync campaign ${camp.id}`, err);
                            }
                        }
                    }
                }
                // Step 3: Automated Lead Sync for all Meta Accounts
                console.log(`[SyncWorker] Starting automated lead sync for ${allAccounts.filter((a) => a.platform === 'meta').length} Meta account(s)`);
                for (const acc of allAccounts) {
                    if (acc.platform === 'meta') {
                        try {
                            yield metaLeadsService.syncLeads(acc.clientId, acc.externalAccountId);
                        }
                        catch (leadErr) {
                            console.error(`Lead sync failed for account ${acc.externalAccountId}:`, leadErr);
                        }
                    }
                }
                yield prisma_1.default.marketingSyncLog.update({
                    where: { id: log.id },
                    data: {
                        status: 'SUCCESS',
                        finishedAt: new Date(),
                        details: `Successfully synced ${successCount} campaigns after discovery.`
                    }
                });
            }
            catch (overallError) {
                yield prisma_1.default.marketingSyncLog.update({
                    where: { id: log.id },
                    data: {
                        status: 'FAILED',
                        finishedAt: new Date(),
                        details: overallError.message
                    }
                });
            }
        });
    }
}
exports.MarketingSyncWorker = MarketingSyncWorker;
