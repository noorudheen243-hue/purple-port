"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const morgan_1 = __importDefault(require("morgan"));
const cookie_parser_1 = __importDefault(require("cookie-parser"));
const compression_1 = __importDefault(require("compression"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const app = (0, express_1.default)();
// Trust proxy for VPS environments (behind Nginx/Caddy)
app.set('trust proxy', 1);
// System: Accounting Module Loaded
// 1. General Rate Limiter (Relaxed)
const limiter = (0, express_rate_limit_1.default)({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: process.env.NODE_ENV === 'production' ? 1000 : 999999, // Very high for dev
    standardHeaders: true,
    legacyHeaders: false,
    message: 'Too many requests from this IP, please try again after 15 minutes'
});
// 2. Strict Auth Limiter (Brute-force protection)
const authLimiter = (0, express_rate_limit_1.default)({
    windowMs: 15 * 60 * 1000,
    max: process.env.NODE_ENV === 'production' ? 100 : 999999, // Disable for dev
    standardHeaders: true,
    legacyHeaders: false,
    message: 'Too many login attempts, please try again later.'
});
// Middleware
app.use((0, compression_1.default)()); // GZIP Compression
app.use((0, helmet_1.default)({
    crossOriginResourcePolicy: { policy: "cross-origin" }
}));
app.use(limiter);
app.use('/api/auth', authLimiter); // Apply strict limit to auth routes
app.use((0, cors_1.default)({
    origin: [
        'http://localhost:5173',
        'http://localhost:5174',
        'http://localhost:5175', // Added to cover more Vite default ports
        'http://localhost:4001', // Allow backend-to-backend calls
        'http://72.61.246.22', // Old VPS IP
        'http://72.61.246.22:4001',
        'http://66.116.224.221', // New VPS IP
        'http://66.116.224.221:4001',
        'https://port.qixads.com', // Custom Domain
        'https://www.port.qixads.com',
        'https://qixport.com',
        'https://www.qixport.com',
        process.env.CLIENT_URL || ''
    ].filter(Boolean),
    credentials: true
}));
app.use((0, morgan_1.default)('dev'));
app.use(express_1.default.json());
app.use(express_1.default.urlencoded({ extended: true }));
app.use((0, cookie_parser_1.default)());
// Global Request Logger for Debugging
app.use((req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
        const duration = Date.now() - start;
        console.log(`[HTTP] ${req.method} ${req.originalUrl} - ${res.statusCode} (${duration}ms)`);
    });
    next();
});
// Routes
app.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});
const routes_1 = __importDefault(require("./modules/auth/routes"));
const routes_2 = __importDefault(require("./modules/tasks/routes"));
const routes_3 = __importDefault(require("./modules/clients/routes"));
const routes_4 = __importDefault(require("./modules/content-types/routes"));
const routes_5 = __importDefault(require("./modules/campaigns/routes"));
const routes_6 = __importDefault(require("./modules/assets/routes"));
const routes_7 = __importDefault(require("./modules/comments/routes"));
const routes_8 = __importDefault(require("./modules/analytics/routes"));
const routes_9 = __importDefault(require("./modules/notifications/routes"));
const routes_10 = __importDefault(require("./modules/accounting/routes"));
const routes_11 = __importDefault(require("./modules/ad_intelligence/routes"));
const routes_12 = __importDefault(require("./modules/team/routes"));
const routes_13 = __importDefault(require("./modules/upload/routes"));
const routes_14 = __importDefault(require("./modules/users/routes"));
const routes_15 = __importDefault(require("./modules/payroll/routes"));
const routes_16 = __importDefault(require("./modules/backup/routes"));
const routes_17 = __importDefault(require("./modules/client_portal/routes"));
const routes_18 = __importDefault(require("./modules/marketing-tasks/routes"));
const routes_19 = __importDefault(require("./modules/settings/routes"));
const routes_20 = __importDefault(require("./modules/whatsapp/routes"));
const path_1 = __importDefault(require("path"));
// Serve Uploads
app.use('/api/uploads', express_1.default.static(path_1.default.join(process.cwd(), 'uploads')));
const routes_21 = __importDefault(require("./modules/system/routes")); // Legacy System Routes
const routes_22 = __importDefault(require("./modules/deployment/routes")); // New Auto-Update Routes
app.use('/api/auth', routes_1.default);
app.use('/api/tasks', routes_2.default);
app.use('/api/clients', routes_3.default);
app.use('/api/content-types', routes_4.default);
app.use('/api/campaigns', routes_5.default);
app.use('/api/assets', routes_6.default);
app.use('/api/comments', routes_7.default);
app.use('/api/analytics', routes_8.default);
app.use('/api/notifications', routes_9.default);
app.use('/api/accounting', routes_10.default);
app.use('/api/ad-intelligence', routes_11.default);
app.use('/api/team', routes_12.default);
app.use('/api/users', routes_14.default);
app.use('/api/upload', routes_13.default);
// System / Deployment Access
app.use('/api/system', routes_21.default);
app.use('/api/deployment', routes_22.default); // Registered here
app.use('/api/client-portal', routes_17.default);
app.use('/api/marketing', routes_18.default);
app.use('/api/payroll', routes_15.default);
app.use('/api/backup', routes_16.default);
const routes_23 = __importDefault(require("./modules/sticky_notes/routes"));
const routes_24 = __importDefault(require("./modules/team/resignation/routes"));
const routes_25 = __importDefault(require("./modules/attendance/routes"));
const biometric_control_routes_1 = __importDefault(require("./modules/attendance/biometric_control.routes"));
const routes_26 = __importDefault(require("./modules/billing/routes"));
const routes_27 = __importDefault(require("./modules/leave/routes"));
app.use('/api/billing', routes_26.default);
app.use('/api/sticky-notes', routes_23.default);
app.use('/api/team/resignation', routes_24.default); // New Module
app.use('/api/attendance/biometric', biometric_control_routes_1.default); // Specific route first
app.use('/api/attendance', routes_25.default); // Generic route second
app.use('/api/leave', routes_27.default);
app.use('/api/settings', routes_19.default);
app.use('/api/whatsapp', routes_20.default);
const routes_28 = __importDefault(require("./modules/chat/routes"));
const routes_29 = __importDefault(require("./modules/launcher/routes"));
const routes_30 = __importDefault(require("./modules/admin/routes"));
const routes_31 = __importDefault(require("./modules/meetings/routes"));
const aiSales_routes_1 = __importDefault(require("./modules/ai_sales_engine/routes/aiSales.routes"));
app.use('/api/chat', routes_28.default);
app.use('/api/launcher', routes_29.default);
app.use('/api/admin', routes_30.default);
app.use('/api/meetings', routes_31.default);
app.use('/api/ai-sales', aiSales_routes_1.default);
const routes_32 = __importDefault(require("./modules/marketing_beta/routes"));
app.use('/api/marketing-beta', routes_32.default);
// --- Production: Serve Frontend ---
// In production, we assume the React build is copied to a 'public' folder in the root
if (process.env.NODE_ENV === 'production') {
    // Serve static files from the React app
    // Correct Path: 'public' folder in the root of the deployment
    const publicPath = path_1.default.join(process.cwd(), 'public');
    app.use(express_1.default.static(publicPath, {
        setHeaders: (res, filePath) => {
            if (filePath.endsWith('index.html')) {
                res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
                res.setHeader('Pragma', 'no-cache');
                res.setHeader('Expires', '0');
            }
        }
    }));
    // The "catchall" handler: for any request that doesn't
    // match one above, send back React's index.html file.
    app.get('*', (req, res) => {
        // Prevent API calls from returning HTML
        if (req.path.startsWith('/api')) {
            res.status(404).json({ message: "API endpoint not found" });
            return;
        }
        res.sendFile(path_1.default.join(publicPath, 'index.html'), {
            headers: {
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'Pragma': 'no-cache',
                'Expires': '0'
            }
        });
    });
}
// Global Error Handler
app.use((err, req, res, next) => {
    console.error('Global Error:', err);
    const statusCode = err.statusCode || 500;
    const message = err.message || 'Internal Server Error';
    res.status(statusCode).json({
        message,
        stack: process.env.NODE_ENV === 'production' ? undefined : err.stack,
    });
});
exports.default = app;
