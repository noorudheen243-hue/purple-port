"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
function checkData() {
    return __awaiter(this, void 0, void 0, function* () {
        const campaigns = yield prisma.marketingCampaign.findMany({
            include: {
                marketingMetrics: {
                    orderBy: { date: 'desc' },
                    take: 1
                }
            }
        });
        console.log('Total Campaigns:', campaigns.length);
        campaigns.forEach(c => {
            console.log(`Campaign: ${c.name} (${c.platform}) - Metrics: ${c.marketingMetrics.length}`);
            if (c.marketingMetrics.length > 0) {
                console.log('Latest Metrics:', c.marketingMetrics[0]);
            }
        });
    });
}
checkData().finally(() => prisma.$disconnect());
