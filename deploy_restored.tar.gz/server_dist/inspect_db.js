"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        const adAccountId = '616308347710249';
        console.log(`Checking database for Ad Account: ${adAccountId}`);
        const accounts = yield prisma.marketingAccount.findMany({
            where: {
                externalAccountId: {
                    contains: adAccountId
                }
            },
            include: {
                client: true,
                metaToken: true
            }
        });
        console.log('Found Marketing Accounts:');
        console.log(JSON.stringify(accounts, null, 2));
        if (accounts.length > 0) {
            const clientId = accounts[0].clientId;
            console.log(`Checking campaigns for Client ID: ${clientId}`);
            const campaigns = yield prisma.marketingCampaign.findMany({
                where: { clientId, platform: 'meta' }
            });
            console.log(`Found ${campaigns.length} Meta campaigns`);
            console.log(JSON.stringify(campaigns.map((c) => ({ id: c.id, name: c.name, externalId: c.externalCampaignId })), null, 2));
        }
        else {
            // Search by client name if account not found
            console.log('Searching for client "Interman Learning"');
            const clients = yield prisma.client.findMany({
                where: {
                    name: {
                        contains: 'Interman Learning',
                        // mode: 'insensitive' // SQLite might not support this directly in all Prisma versions
                    }
                }
            });
            console.log('Found Clients:');
            console.log(JSON.stringify(clients, null, 2));
            if (clients.length > 0) {
                const clientId = clients[0].id;
                const clientAccounts = yield prisma.marketingAccount.findMany({
                    where: { clientId }
                });
                console.log(`Found ${clientAccounts.length} marketing accounts for this client`);
                console.log(JSON.stringify(clientAccounts, null, 2));
            }
        }
    });
}
main()
    .catch(e => console.error(e))
    .finally(() => __awaiter(void 0, void 0, void 0, function* () { return yield prisma.$disconnect(); }));
