"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        console.log('Listing all clients:');
        const clients = yield prisma.client.findMany({
            select: { id: true, name: true }
        });
        console.log(JSON.stringify(clients, null, 2));
        console.log('Listing all Meta tokens:');
        const tokens = yield prisma.metaToken.findMany();
        console.log(JSON.stringify(tokens, null, 2));
        console.log('Listing all marketing accounts:');
        const accounts = yield prisma.marketingAccount.findMany({
            include: { client: { select: { name: true } } }
        });
        console.log(JSON.stringify(accounts, null, 2));
    });
}
main()
    .catch(e => console.error(e))
    .finally(() => __awaiter(void 0, void 0, void 0, function* () { return yield prisma.$disconnect(); }));
