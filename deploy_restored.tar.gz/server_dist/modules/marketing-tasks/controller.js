"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.middleware = exports.getAccounts = void 0;
exports.manualSync = manualSync;
exports.syncCampaign = syncCampaign;
exports.getMetaAccountStatus = getMetaAccountStatus;
exports.getMetrics = getMetrics;
exports.getAiTips = getAiTips;
exports.authMeta = authMeta;
exports.metaCallback = metaCallback;
exports.getMetaProfiles = getMetaProfiles;
exports.linkAccountToProfile = linkAccountToProfile;
exports.authGoogle = authGoogle;
exports.googleCallback = googleCallback;
exports.getIntegrationStatus = getIntegrationStatus;
exports.getAvailableAccounts = getAvailableAccounts;
exports.selectAccount = selectAccount;
exports.disconnectAccount = disconnectAccount;
exports.getLeads = getLeads;
exports.createLead = createLead;
exports.updateLeadFeedback = updateLeadFeedback;
exports.updateLead = updateLead;
exports.deleteLead = deleteLead;
exports.addFollowUp = addFollowUp;
exports.syncLeads = syncLeads;
exports.getMetaCampaignsDetailed = getMetaCampaignsDetailed;
exports.getMetaAdSets = getMetaAdSets;
exports.getMetaAds = getMetaAds;
exports.createMetaCampaign = createMetaCampaign;
exports.createMetaAdSet = createMetaAdSet;
exports.updateMetaStatus = updateMetaStatus;
exports.sendReport = sendReport;
const axios_1 = __importDefault(require("axios"));
const date_fns_1 = require("date-fns");
const prisma_1 = __importDefault(require("../../utils/prisma"));
const metaAdsService_1 = require("./services/metaAdsService");
const googleAdsService_1 = require("./services/googleAdsService");
const metaLeadsService_1 = require("./services/metaLeadsService");
const syncWorker_1 = require("./sync/syncWorker");
const aiSalesEngine_service_1 = require("../ai_sales_engine/services/aiSalesEngine.service");
const metaService = new metaAdsService_1.MetaAdsService();
const googleService = new googleAdsService_1.GoogleAdsService();
const metaLeadsService = new metaLeadsService_1.MetaLeadsService();
// Simple feature flag check
function featureEnabled(req, res, next) {
    if (process.env.MARKETING_ENGINE_ENABLED !== 'true') {
        return res.status(403).json({ message: 'Marketing engine feature is disabled.' });
    }
    next();
}
function manualSync(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { clientId, daysBack } = req.body;
            if (clientId) {
                // New Sync All for Client logic (Synchronous for immediate feedback if desired, or background)
                syncWorker_1.MarketingSyncWorker.syncClientCampaigns(clientId, daysBack || 35).catch(err => {
                    console.error(`[SyncController] Client Sync Error for ${clientId}:`, err);
                });
                return res.json({ message: 'Client campaign sync started in background.' });
            }
            // Legacy Global Sync logic
            const currentYear = new Date().getFullYear();
            const startOfYear = new Date(currentYear, 0, 1);
            const today = new Date();
            const daysToCurrentYear = Math.ceil((today.getTime() - startOfYear.getTime()) / (1000 * 3600 * 24)) + 1;
            syncWorker_1.MarketingSyncWorker.syncAllActiveCampaigns(daysBack || daysToCurrentYear).catch(err => {
                console.error('Background Marketing Sync Error:', err);
            });
            res.json({ message: `Global sync started successfully.` });
        }
        catch (error) {
            console.error('Marketing Sync Error:', error);
            res.status(500).json({ message: 'Sync failed', error: error.message });
        }
    });
}
function syncCampaign(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { campaignId, daysBack, isPreview, externalAccountId, platform, clientId: bodyClientId, targetDate } = req.body;
            if (!campaignId)
                return res.status(400).json({ message: 'campaignId is required' });
            // Ensure we have a valid clientId
            const clientId = bodyClientId || req.query.clientId;
            if (!clientId) {
                return res.status(400).json({ message: 'clientId is required for synchronization' });
            }
            if (isPreview && externalAccountId && platform) {
                const today = new Date();
                // 1. Fetch metadata first to find the true campaign start date
                let campaignMetadata = null;
                if (platform === 'meta') {
                    const metaCampaigns = yield metaService.fetchCampaigns(externalAccountId);
                    // Use robust string comparison to avoid large-number precision issues
                    campaignMetadata = metaCampaigns.find(c => String(c.id) === String(campaignId));
                }
                else if (platform === 'google') {
                    const googleCampaigns = yield googleService.fetchCampaigns(externalAccountId);
                    campaignMetadata = googleCampaigns.find(c => String(c.id) === String(campaignId));
                }
                // Determine Start Date
                let startDate = new Date();
                let endDate = null;
                if (targetDate) {
                    const target = new Date(targetDate);
                    startDate = new Date(target.getFullYear(), target.getMonth(), 1);
                    endDate = new Date(target.getFullYear(), target.getMonth() + 1, 0);
                    // Ensure endDate doesn't exceed today to prevent querying future data on active months
                    if (endDate > new Date())
                        endDate = new Date();
                }
                else {
                    const rawStart = (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.start_time) || (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.start_date) || (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.startDate);
                    if (rawStart) {
                        startDate = new Date(rawStart);
                    }
                    else {
                        startDate.setFullYear(today.getFullYear() - 2);
                    }
                    const rawEnd = (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.stop_time) || (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.end_date) || (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.endDate);
                    if (rawEnd)
                        endDate = new Date(rawEnd);
                }
                startDate.setHours(0, 0, 0, 0);
                console.log(`[SyncController] Syncing ${platform} Campaign: ${campaignId} (Client: ${clientId}) from ${startDate.toISOString()}`);
                let externalMetrics = [];
                if (platform === 'meta') {
                    externalMetrics = yield metaService.fetchLifetimeMetrics(campaignId, externalAccountId, startDate, endDate || new Date());
                }
                else if (platform === 'google') {
                    externalMetrics = yield googleService.fetchMetrics(campaignId, externalAccountId, startDate, today);
                }
                console.log(`[SyncController] Fetched ${externalMetrics.length} metric rows.`);
                // 2. Aggregate Metrics (Sum everything for a Lifetime total)
                const totals = externalMetrics.reduce((acc, curr) => {
                    acc.spend += parseFloat(curr.spend || 0);
                    acc.results += parseInt(curr.results || curr.conversions || 0);
                    acc.impressions += parseInt(curr.impressions || 0);
                    acc.reach += parseInt(curr.reach || 0);
                    acc.messaging_conversations += parseInt(curr.messaging_conversations || 0);
                    acc.new_messaging_contacts += parseInt(curr.new_messaging_contacts || 0);
                    acc.purchases += parseInt(curr.purchases || 0);
                    if (curr.results_type && acc.results_type === 'Results')
                        acc.results_type = curr.results_type;
                    return acc;
                }, {
                    spend: 0, results: 0, impressions: 0, reach: 0,
                    messaging_conversations: 0, new_messaging_contacts: 0, purchases: 0, results_type: 'Results'
                });
                // Ensure the campaign is registered in our system for tracking
                let campRecord = yield prisma_1.default.marketingCampaign.findFirst({
                    where: {
                        externalCampaignId: String(campaignId),
                        platform: platform.toLowerCase(),
                        clientId: clientId
                    }
                });
                if (campRecord) {
                    campRecord = yield prisma_1.default.marketingCampaign.update({
                        where: { id: campRecord.id },
                        data: {
                            name: (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.name) || (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.title),
                            status: (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.effective_status) || (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.status),
                            objective: campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.objective,
                            budget: parseFloat((campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.daily_budget) || (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.lifetime_budget) || '0') / 100,
                            startDate: startDate,
                            ends: endDate
                        }
                    });
                }
                else {
                    campRecord = yield prisma_1.default.marketingCampaign.create({
                        data: {
                            clientId: clientId,
                            platform: platform.toLowerCase(),
                            externalCampaignId: String(campaignId),
                            name: (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.name) || (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.title),
                            status: (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.effective_status) || (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.status),
                            objective: campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.objective,
                            budget: parseFloat((campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.daily_budget) || (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.lifetime_budget) || '0') / 100,
                            startDate: startDate,
                            ends: endDate
                        }
                    });
                }
                // Aggregate and update metrics
                const latestMetric = Object.assign(Object.assign({}, totals), { results_cost: totals.results > 0 ? totals.spend / totals.results : 0, 
                    // Automated fields
                    name: (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.name) || (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.title), startDate: startDate, ends: endDate, status: (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.effective_status) || (campaignMetadata === null || campaignMetadata === void 0 ? void 0 : campaignMetadata.status), id: campRecord.id // Include our internal ID for saving
                 });
                return res.json({ success: true, latestMetric });
            }
            const latestMetric = yield syncWorker_1.MarketingSyncWorker.syncSingleCampaign(campaignId, daysBack || 7);
            res.json({ success: true, latestMetric });
        }
        catch (error) {
            console.error('Single Campaign Sync Error:', error.message);
            res.status(500).json({ message: 'Sync failed', error: error.message });
        }
    });
}
function getMetaAccountStatus(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e;
        try {
            const { clientId } = req.query;
            if (!clientId)
                return res.status(400).json({ message: 'clientId is required' });
            console.log(`[getMetaAccountStatus] Checking status for client: ${clientId}`);
            const account = yield prisma_1.default.marketingAccount.findFirst({
                where: { clientId: clientId, platform: 'meta' },
                include: { metaToken: true }
            });
            if (!account) {
                return res.json({ connected: false, status: 'NOT_CONNECTED' });
            }
            // AUTO-FIX: If the ID has leading/trailing spaces, fix it in the DB immediately
            if (account.externalAccountId && account.externalAccountId !== account.externalAccountId.trim()) {
                const trimmed = account.externalAccountId.trim();
                console.log(`[FIX] Trimming whitespace for Meta ID: "${account.externalAccountId}" -> "${trimmed}"`);
                yield prisma_1.default.marketingAccount.update({
                    where: { id: account.id },
                    data: { externalAccountId: trimmed }
                });
                account.externalAccountId = trimmed;
            }
            // Check token health
            const now = new Date();
            const isExpired = account.tokenExpiry && new Date(account.tokenExpiry) < now;
            const profileExpired = ((_a = account.metaToken) === null || _a === void 0 ? void 0 : _a.expires_at) && new Date(account.metaToken.expires_at) < now;
            if (isExpired || profileExpired) {
                return res.json({ connected: true, status: 'EXPIRED', accountName: (_b = account.metaToken) === null || _b === void 0 ? void 0 : _b.account_name });
            }
            // Fetch campaigns if active
            let campaigns = [];
            let status = 'ACTIVE';
            let errorMessage = '';
            console.log(`[DEBUG getMetaAccountStatus] Client: ${clientId}, AdAccount: ${account.externalAccountId}`);
            try {
                if (account.externalAccountId && account.externalAccountId !== 'meta-account-linked' && account.externalAccountId !== 'pending-selection') {
                    campaigns = yield metaService.fetchCampaigns(account.externalAccountId, clientId);
                    console.log(`[DEBUG getMetaAccountStatus] Fetched ${campaigns.length} campaigns for ${account.externalAccountId}`);
                }
                else {
                    console.log(`[DEBUG getMetaAccountStatus] Skipping fetch: externalAccountId is placeholder (${account.externalAccountId})`);
                    status = 'PENDING_SELECTION';
                }
            }
            catch (err) {
                console.error('[DEBUG getMetaAccountStatus] Error fetching Meta campaigns:', err.message);
                // Handle Meta API errors specifically
                const fbError = (_d = (_c = err.response) === null || _c === void 0 ? void 0 : _c.data) === null || _d === void 0 ? void 0 : _d.error;
                if (fbError) {
                    if (fbError.code === 190 || fbError.type === 'OAuthException') {
                        status = 'EXPIRED';
                        errorMessage = fbError.message;
                    }
                    else if (fbError.code === 200) {
                        status = 'PERMISSION_ERROR';
                        errorMessage = fbError.message;
                    }
                }
            }
            res.json({
                connected: true,
                status,
                errorMessage,
                accountName: (_e = account.metaToken) === null || _e === void 0 ? void 0 : _e.account_name,
                externalAccountId: account.externalAccountId,
                campaigns // Return campaigns to populate dropdown
            });
        }
        catch (error) {
            res.status(500).json({ connected: false, status: 'ERROR', error: error.message });
        }
    });
}
function getMetrics(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { clientId, platform, from, to, status, groupId } = req.query;
            if (!from || !to) {
                return res.status(400).json({ message: 'from and to dates are required.' });
            }
            const dateFilter = {
                gte: new Date(from),
                lte: new Date(to)
            };
            const whereClause = {
                date: dateFilter
            };
            // 1. Build Strict Group Filter
            if (groupId && groupId !== 'all' && groupId !== 'undefined') {
                whereClause.campaign = {
                    group_id: groupId
                };
                // If group is specific, we don't necessarily need clientId filter 
                // because group_id is unique enough, but we include it if provided and valid
                if (clientId && clientId !== 'all' && clientId !== '') {
                    whereClause.campaign.clientId = clientId;
                }
            }
            else if (clientId && clientId !== 'all' && clientId !== '') {
                whereClause.campaign = {
                    clientId: clientId
                };
            }
            else {
                // Unrestricted - but usually discouraged for metrics
                whereClause.campaign = {
                    clientId: { not: '' }
                };
            }
            if (platform && platform !== 'all') {
                if (!whereClause.campaign)
                    whereClause.campaign = {};
                whereClause.campaign.platform = platform;
            }
            if (status === 'active') {
                if (!whereClause.campaign)
                    whereClause.campaign = {};
                whereClause.campaign.status = { in: ['ACTIVE', 'ENABLED'] };
            }
            else if (status === 'all') {
                if (!whereClause.campaign)
                    whereClause.campaign = {};
                whereClause.campaign.status = { in: ['ACTIVE', 'PAUSED', 'ARCHIVED', 'ENABLED'] };
            }
            const metrics = yield prisma_1.default.marketingMetric.findMany({
                where: whereClause,
                include: {
                    campaign: {
                        select: {
                            id: true,
                            name: true,
                            platform: true,
                            objective: true,
                            status: true,
                            budget: true,
                            startDate: true,
                            ends: true
                        }
                    }
                },
                orderBy: {
                    date: 'asc'
                }
            });
            // 2. Calculated Isolated Summary for the Group
            const summary = metrics.reduce((acc, curr) => {
                acc.impressions += (curr.impressions || 0);
                acc.clicks += (curr.clicks || 0);
                acc.spend += (curr.spend || 0);
                acc.conversions += (curr.conversions || 0);
                acc.reach += (curr.reach || 0);
                acc.results += (curr.results || 0);
                acc.conversations += (curr.conversations || 0);
                return acc;
            }, { impressions: 0, clicks: 0, spend: 0, conversions: 0, reach: 0, results: 0, conversations: 0 });
            // 3. Campaign Portfolio (Filtered by Group)
            const campaignWhere = {};
            if (groupId && groupId !== 'all' && groupId !== 'undefined') {
                campaignWhere.group_id = groupId;
                if (clientId && clientId !== 'all' && clientId !== '') {
                    campaignWhere.clientId = clientId;
                }
            }
            else if (clientId && clientId !== 'all' && clientId !== '') {
                campaignWhere.clientId = clientId;
            }
            if (platform && platform !== 'all')
                campaignWhere.platform = platform;
            if (status === 'active') {
                campaignWhere.status = { in: ['ACTIVE', 'ENABLED'] };
            }
            else if (status === 'all') {
                campaignWhere.status = { in: ['ACTIVE', 'PAUSED', 'ARCHIVED', 'ENABLED'] };
            }
            const allCampaigns = yield prisma_1.default.marketingCampaign.findMany({
                where: campaignWhere,
                select: {
                    id: true,
                    name: true,
                    platform: true,
                    objective: true,
                    status: true,
                    budget: true,
                    startDate: true,
                    ends: true,
                    group: {
                        select: {
                            id: true,
                            name: true
                        }
                    }
                }
            });
            // Fetch lead counts for these campaigns
            const leadCounts = yield prisma_1.default.lead.groupBy({
                by: ['campaignId'],
                where: {
                    campaignId: { in: allCampaigns.map((c) => c.id) }
                },
                _count: {
                    _all: true
                }
            });
            // Map metrics to campaigns
            const campaignsWithMetrics = allCampaigns.map((camp) => {
                const campMetrics = metrics.filter((m) => m.campaignId === camp.id);
                const aggr = campMetrics.reduce((acc, curr) => {
                    acc.impressions += (curr.impressions || 0);
                    acc.spend += (curr.spend || 0);
                    acc.reach += (curr.reach || 0);
                    acc.results += (curr.results || 0);
                    acc.conversations += (curr.conversations || 0);
                    acc.conversions += (curr.conversions || 0);
                    return acc;
                }, { impressions: 0, spend: 0, reach: 0, results: 0, conversations: 0, conversions: 0 });
                const leadsItem = leadCounts.find((lc) => lc.campaignId === camp.id);
                return Object.assign(Object.assign({}, camp), { metrics: aggr, leadsCount: (leadsItem === null || leadsItem === void 0 ? void 0 : leadsItem._count._all) || 0 });
            });
            res.json({
                summary,
                data: metrics,
                campaigns: campaignsWithMetrics
            });
        }
        catch (error) {
            console.error('Error fetching marketing metrics:', error);
            res.status(500).json({ message: 'Error fetching metrics', error: error.message });
        }
    });
}
function getAiTips(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { clientId } = req.query;
            if (!clientId)
                return res.status(400).json({ message: 'clientId is required.' });
            const tips = yield require('./services/marketingAiService').MarketingAIService.generateTips(clientId);
            res.json(tips);
        }
        catch (error) {
            console.error('Error generating AI tips:', error);
            res.status(500).json({ message: 'Error generating tips', error: error.message });
        }
    });
}
// ==========================================
// OAuth 2.0 Integration Handlers
// ==========================================
function authMeta(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const { clientId } = req.query; // clientId is optional now for global profile linking
        const state = clientId || 'global';
        // Load credentials from DB first, fallback to ENV
        const settings = yield prisma_1.default.systemSetting.findMany({
            where: { key: { in: ['META_APP_ID', 'META_APP_SECRET'] } }
        });
        const settingsMap = settings.reduce((acc, curr) => {
            acc[curr.key] = curr.value;
            return acc;
        }, {});
        const appId = (settingsMap['META_APP_ID'] || process.env.META_APP_ID || '').trim();
        // ULTIMATE FIX: Force HTTPS and use hardcoded production domain if present
        const reqHost = req.get('host');
        const isLocal = (reqHost === null || reqHost === void 0 ? void 0 : reqHost.includes('localhost')) || (reqHost === null || reqHost === void 0 ? void 0 : reqHost.includes('127.0.0.1'));
        const protocol = isLocal ? 'http' : 'https';
        const baseUrl = process.env.PRODUCTION_API_URL || `${protocol}://${reqHost}`;
        // Ensure baseUrl doesn't have trailing slash for consistency
        const cleanBaseUrl = baseUrl.replace(/\/$/, '');
        // Double-force HTTPS for redirectUri if not local
        let redirectUri = `${cleanBaseUrl}/api/marketing/auth/meta/callback`;
        if (!isLocal && redirectUri.startsWith('http:')) {
            redirectUri = redirectUri.replace('http:', 'https:');
        }
        console.log(`[MetaAuth] Initiating OAuth for App ID: "${appId}" (Redirect: ${redirectUri})`);
        if (!appId || appId.includes('placeholder')) {
            return res.status(400).send('Meta App ID is not configured properly in Settings. Current value: ' + appId);
        }
        // Redirect to Facebook Dialog with reauthenticate to allow switching accounts easily
        const authUrl = `https://www.facebook.com/v19.0/dialog/oauth?client_id=${appId}&redirect_uri=${redirectUri}&state=${state}&scope=public_profile,ads_management,ads_read,business_management&auth_type=reauthenticate`;
        console.log(`[MetaAuth] Redirecting to: ${authUrl}`);
        res.redirect(authUrl);
    });
}
function metaCallback(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e;
        const { code, state } = req.query;
        if (!code || !state)
            return res.status(400).send('Missing code or state');
        const clientId = state === 'global' ? null : state;
        // Fallback if no user in req (for testing/local or redirect bounce)
        let userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id;
        if (!userId) {
            const adminUser = yield prisma_1.default.user.findFirst({
                where: { role: 'ADMIN' },
                select: { id: true }
            });
            if (!adminUser) {
                return res.status(500).send('No Admin user found to link this Meta account to.');
            }
            userId = adminUser.id;
        }
        let settingsMap = {};
        try {
            const settings = yield prisma_1.default.systemSetting.findMany({
                where: { key: { in: ['META_APP_ID', 'META_APP_SECRET'] } }
            });
            settingsMap = settings.reduce((acc, curr) => {
                acc[curr.key] = curr.value;
                return acc;
            }, {});
            const appId = settingsMap['META_APP_ID'] || process.env.META_APP_ID;
            const appSecret = settingsMap['META_APP_SECRET'] || process.env.META_APP_SECRET;
            // ULTIMATE FIX: Force HTTPS and use hardcoded production domain for callback exchange
            const reqHost = req.get('host');
            const isLocal = (reqHost === null || reqHost === void 0 ? void 0 : reqHost.includes('localhost')) || (reqHost === null || reqHost === void 0 ? void 0 : reqHost.includes('127.0.0.1'));
            const protocol = isLocal ? 'http' : 'https';
            const baseUrl = process.env.PRODUCTION_API_URL || `${protocol}://${reqHost}`;
            const cleanBaseUrl = baseUrl.replace(/\/$/, '');
            let redirectUri = `${cleanBaseUrl}/api/marketing/auth/meta/callback`;
            if (!isLocal && redirectUri.startsWith('http:')) {
                redirectUri = redirectUri.replace('http:', 'https:');
            }
            console.log(`[MetaCallback] Exchanging token for App ID: ${appId} (Redirect: ${redirectUri})`);
            // Exchange code for short-lived token
            const tokenRes = yield axios_1.default.get(`https://graph.facebook.com/v19.0/oauth/access_token`, {
                params: {
                    client_id: appId,
                    redirect_uri: redirectUri,
                    client_secret: appSecret,
                    code
                }
            });
            const shortToken = tokenRes.data.access_token;
            // Exchange for long-lived token
            const longTokenRes = yield axios_1.default.get(`https://graph.facebook.com/v19.0/oauth/access_token`, {
                params: {
                    grant_type: 'fb_exchange_token',
                    client_id: appId,
                    client_secret: appSecret,
                    fb_exchange_token: shortToken
                }
            });
            const longToken = longTokenRes.data.access_token;
            // Fetch Meta user info (Name and ID)
            const meRes = yield axios_1.default.get(`https://graph.facebook.com/v19.0/me`, {
                params: { access_token: longToken, fields: 'id,name' }
            });
            const metaUserName = meRes.data.name;
            const metaUserId = meRes.data.id;
            // Bypass Prisma SQLite 'upsert' bug - Use manual find + update/create
            const existingMetaToken = yield prisma_1.default.metaToken.findFirst({
                where: { meta_user_id: metaUserId, user_id: userId }
            });
            let metaToken;
            if (existingMetaToken) {
                metaToken = yield prisma_1.default.metaToken.update({
                    where: { id: existingMetaToken.id },
                    data: {
                        access_token: longToken,
                        account_name: metaUserName,
                        expires_at: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000)
                    }
                });
            }
            else {
                metaToken = yield prisma_1.default.metaToken.create({
                    data: {
                        id: `token-${metaUserId}-${userId}`,
                        user_id: userId,
                        access_token: longToken,
                        account_name: metaUserName,
                        meta_user_id: metaUserId,
                        expires_at: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000)
                    }
                });
            }
            // If clientId was provided, also update/create the MarketingAccount
            if (clientId) {
                const existingAccount = yield prisma_1.default.marketingAccount.findFirst({
                    where: { clientId, platform: 'meta' }
                });
                if (existingAccount) {
                    yield prisma_1.default.marketingAccount.update({
                        where: { id: existingAccount.id },
                        data: {
                            accessToken: longToken,
                            tokenExpiry: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000),
                            metaTokenId: metaToken.id
                        }
                    });
                }
                else {
                    yield prisma_1.default.marketingAccount.create({
                        data: {
                            clientId,
                            platform: 'meta',
                            externalAccountId: 'meta-account-linked',
                            accessToken: longToken,
                            tokenExpiry: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000),
                            metaTokenId: metaToken.id
                        }
                    });
                }
            }
            res.redirect(`${baseUrl}/dashboard/marketing-integrations?success=meta`);
        }
        catch (e) {
            console.error('Meta OAuth Error:', ((_b = e.response) === null || _b === void 0 ? void 0 : _b.data) || e.message);
            const fbError = (_d = (_c = e.response) === null || _c === void 0 ? void 0 : _c.data) === null || _d === void 0 ? void 0 : _d.error;
            let userMessage = e.message;
            if (fbError) {
                if ((_e = fbError.message) === null || _e === void 0 ? void 0 : _e.includes('updating additional details')) {
                    userMessage = `Meta requires your app to complete a "Data Use Checkup" or "App Review" update. Please visit developers.facebook.com for App ID: ${settingsMap['META_APP_ID'] || process.env.META_APP_ID}`;
                }
                else {
                    userMessage = fbError.message;
                }
            }
            res.status(500).send('Callback Failed: ' + userMessage);
        }
    });
}
function getMetaProfiles(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const profiles = yield prisma_1.default.metaToken.findMany({
                where: { isActive: true },
                select: {
                    id: true,
                    account_name: true,
                    meta_user_id: true,
                    updatedAt: true,
                    expires_at: true,
                    marketingAccounts: {
                        select: {
                            id: true,
                            clientId: true,
                            metaTokenId: true,
                            externalAccountId: true,
                            client: {
                                select: {
                                    id: true,
                                    name: true
                                }
                            }
                        }
                    }
                }
            });
            // Compute token health status for each profile
            const now = Date.now();
            const enriched = profiles.map((p) => (Object.assign(Object.assign({}, p), { tokenStatus: p.expires_at && new Date(p.expires_at).getTime() < now ? 'EXPIRED' : 'ACTIVE' })));
            res.json(enriched);
        }
        catch (e) {
            res.status(500).json({ error: e.message });
        }
    });
}
const getAccounts = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { id } = req.user;
    const { clientId } = req.query;
    try {
        const accounts = yield metaService.fetchAccounts(id, clientId);
        res.json(accounts);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
exports.getAccounts = getAccounts;
function linkAccountToProfile(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const { clientId, profileId, externalAccountId } = req.body;
        if (!clientId || !profileId)
            return res.status(400).send('Missing clientId or profileId');
        try {
            const profile = yield prisma_1.default.metaToken.findUnique({ where: { id: profileId } });
            if (!profile)
                return res.status(404).send('Profile not found');
            const existingAccount = yield prisma_1.default.marketingAccount.findFirst({
                where: { clientId, platform: 'meta' }
            });
            if (existingAccount) {
                yield prisma_1.default.marketingAccount.update({
                    where: { id: existingAccount.id },
                    data: {
                        metaTokenId: profileId,
                        accessToken: profile.access_token,
                        externalAccountId: externalAccountId || existingAccount.externalAccountId
                    }
                });
            }
            else {
                yield prisma_1.default.marketingAccount.create({
                    data: {
                        clientId,
                        platform: 'meta',
                        metaTokenId: profileId,
                        accessToken: profile.access_token,
                        externalAccountId: externalAccountId || 'pending-selection'
                    }
                });
            }
            res.json({ success: true });
        }
        catch (e) {
            res.status(500).json({ error: e.message });
        }
    });
}
function authGoogle(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const { clientId } = req.query;
        if (!clientId)
            return res.status(400).send('clientId is required');
        const googleClientId = process.env.GOOGLE_CLIENT_ID;
        // Dynamically match the request's exact host for Google OAuth compatibility
        const reqHost = req.get('host');
        const protocol = process.env.NODE_ENV === 'production' ? 'https' : 'http';
        const baseUrl = `${protocol}://${reqHost}`;
        const redirectUri = `${baseUrl}/api/marketing/auth/google/callback`;
        // Sandbox Bypass: If Client ID is a placeholder, perform a mock redirect to our own callback
        if (!googleClientId || googleClientId.includes('placeholder')) {
            console.log(`[SANDBOX] Bypassing Google OAuth for client: ${clientId}`);
            return res.redirect(`${redirectUri}?code=sandbox&state=${clientId}`);
        }
        const scope = 'https://www.googleapis.com/auth/adwords';
        // Redirect to Google Dialog
        const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${googleClientId}&redirect_uri=${redirectUri}&response_type=code&scope=${scope}&access_type=offline&prompt=consent&state=${clientId}`;
        res.redirect(authUrl);
    });
}
function googleCallback(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c;
        const { code, state: clientId } = req.query;
        if (!code || !clientId)
            return res.status(400).send('Missing code or clientId');
        // Sandbox Handler
        if (code === 'sandbox') {
            yield prisma_1.default.marketingAccount.deleteMany({
                where: { clientId: clientId, platform: 'google' }
            });
            yield prisma_1.default.marketingAccount.create({
                data: {
                    clientId: clientId,
                    platform: 'google',
                    externalAccountId: 'mock-google-ads-account',
                    accessToken: 'mock-access-token-' + clientId,
                    refreshToken: 'mock-refresh-token-' + clientId,
                    tokenExpiry: new Date(Date.now() + 3600 * 1000)
                }
            });
            // Use dynamic baseUrl for final redirect to frontend
            const reqHost = req.get('host');
            const protocol = process.env.NODE_ENV === 'production' ? 'https' : 'http';
            const baseUrl = `${protocol}://${reqHost}`;
            return res.redirect(`${baseUrl}/dashboard/marketing-integrations?success=google`);
        }
        try {
            const googleClientId = process.env.GOOGLE_CLIENT_ID;
            const googleClientSecret = process.env.GOOGLE_CLIENT_SECRET;
            // Dynamically match the request's exact host for Google OAuth callback matching
            const reqHost = req.get('host');
            const protocol = process.env.NODE_ENV === 'production' ? 'https' : 'http';
            const baseUrl = `${protocol}://${reqHost}`;
            const redirectUri = `${baseUrl}/api/marketing/auth/google/callback`;
            const tokenRes = yield axios_1.default.post('https://oauth2.googleapis.com/token', {
                code,
                client_id: googleClientId,
                client_secret: googleClientSecret,
                redirect_uri: redirectUri,
                grant_type: 'authorization_code'
            });
            const { access_token, refresh_token, expires_in } = tokenRes.data;
            // Clean up old ones for this client
            yield prisma_1.default.marketingAccount.deleteMany({
                where: { clientId: clientId, platform: 'google' }
            });
            yield prisma_1.default.marketingAccount.create({
                data: {
                    clientId: clientId,
                    platform: 'google',
                    externalAccountId: 'google-account-linked', // A more complete flow might query accessibleCustomers
                    accessToken: access_token,
                    refreshToken: refresh_token || null,
                    tokenExpiry: new Date(Date.now() + (expires_in || 3600) * 1000)
                }
            });
            res.redirect(`${process.env.CLIENT_URL || 'http://localhost:5173'}/dashboard/marketing-integrations?success=google`);
        }
        catch (e) {
            console.error('Google OAuth Error:', ((_a = e.response) === null || _a === void 0 ? void 0 : _a.data) || e.message);
            res.status(500).send('Callback Failed: ' + (((_c = (_b = e.response) === null || _b === void 0 ? void 0 : _b.data) === null || _c === void 0 ? void 0 : _c.error_description) || e.message));
        }
    });
}
// ==========================================
// Account Discovery & Selection
// ==========================================
function getIntegrationStatus(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const { clientId } = req.query;
        if (!clientId)
            return res.status(400).send('clientId is required');
        try {
            const accounts = yield prisma_1.default.marketingAccount.findMany({
                where: { clientId: clientId },
                select: {
                    platform: true,
                    externalAccountId: true,
                    accessToken: true
                }
            });
            const status = {
                meta: accounts.find((a) => a.platform === 'meta'),
                google: accounts.find((a) => a.platform === 'google')
            };
            res.json(status);
        }
        catch (e) {
            console.error('Status Check Error:', e.message);
            res.status(500).json({ message: 'Failed to check status', error: e.message });
        }
    });
}
function getAvailableAccounts(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const { id: userId } = req.user;
        const { clientId, platform: queryPlatform, profileId } = req.query;
        // Default to 'meta' if profileId is provided (as it's specifically for Meta)
        const platform = queryPlatform || (profileId ? 'meta' : null);
        if (!platform)
            return res.status(400).send('platform is required');
        if (!clientId && !profileId)
            return res.status(400).send('clientId or profileId is required');
        try {
            if (platform === 'meta') {
                const accounts = yield metaService.fetchAccounts(userId, clientId, profileId);
                return res.json(accounts);
            }
            const account = yield prisma_1.default.marketingAccount.findFirst({
                where: { clientId: clientId, platform: platform }
            });
            if (!account)
                return res.status(404).json({ message: 'No connected account found for this client and platform.' });
            // Sandbox Check (Google/Other)
            if (((_a = account.accessToken) === null || _a === void 0 ? void 0 : _a.startsWith('mock-')) || account.accessToken === 'sandbox') {
                const mockAccounts = [
                    { id: '123-456-7890', name: 'Sandbox Google Ads A' },
                    { id: '098-765-4321', name: 'Sandbox Google Ads B' }
                ];
                return res.json(mockAccounts);
            }
            // Real API Calls for Google
            if (platform === 'google') {
                // Placeholder: Google Ads customer discovery usually happens during OAuth or via specific service
                return res.json([{ id: account.externalAccountId, name: 'Google Ads Account' }]);
            }
            res.status(400).send('Unsupported platform');
        }
        catch (e) {
            console.error('Fetch Accounts Error:', ((_b = e.response) === null || _b === void 0 ? void 0 : _b.data) || e.message);
            res.status(500).json({ message: 'Failed to fetch available accounts', error: e.message });
        }
    });
}
function selectAccount(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const { clientId, platform, externalAccountId, profileId } = req.body;
        if (!clientId || !platform || !externalAccountId) {
            return res.status(400).send('clientId, platform, and externalAccountId are required');
        }
        try {
            console.log(`[DEBUG selectAccount] Received Request:`, req.body);
            // Use findFirst + create/update or upsert if possible with composite unique (which we don't have yet)
            const existing = yield prisma_1.default.marketingAccount.findFirst({
                where: { clientId, platform }
            });
            console.log(`[DEBUG selectAccount] Existing Account Found:`, !!existing);
            let metaTokenId = profileId;
            let accessToken = undefined;
            // If no profileId provided, try to find an existing one linked to this client
            if (!metaTokenId) {
                const linked = yield prisma_1.default.marketingAccount.findFirst({
                    where: { clientId, platform, NOT: { metaTokenId: null } }
                });
                metaTokenId = linked === null || linked === void 0 ? void 0 : linked.metaTokenId;
                accessToken = linked === null || linked === void 0 ? void 0 : linked.accessToken;
            }
            else {
                // Fetch token for the provided profileId
                const profile = yield prisma_1.default.metaToken.findUnique({ where: { id: profileId } });
                if (profile)
                    accessToken = profile.access_token;
            }
            if (existing) {
                // If the ID is changing, delete old campaigns to avoid data mixing
                if (existing.externalAccountId !== externalAccountId) {
                    console.log(`[DEBUG selectAccount] ID changed from ${existing.externalAccountId} to ${externalAccountId}. Deleting old campaigns.`);
                    const oldCampaigns = yield prisma_1.default.marketingCampaign.findMany({
                        where: { clientId, platform },
                        select: { id: true }
                    });
                    const oldCampaignIds = oldCampaigns.map((c) => c.id);
                    if (oldCampaignIds.length > 0) {
                        yield prisma_1.default.marketingMetric.deleteMany({
                            where: { campaignId: { in: oldCampaignIds } }
                        });
                        yield prisma_1.default.marketingCampaign.deleteMany({
                            where: { id: { in: oldCampaignIds } }
                        });
                    }
                }
                const updated = yield prisma_1.default.marketingAccount.update({
                    where: { id: existing.id },
                    data: {
                        externalAccountId,
                        metaTokenId: metaTokenId || existing.metaTokenId,
                        accessToken: accessToken || existing.accessToken
                    }
                });
                console.log(`[DEBUG selectAccount] Update successful. New externalAccountId in DB:`, updated.externalAccountId);
            }
            else {
                const created = yield prisma_1.default.marketingAccount.create({
                    data: {
                        clientId,
                        platform,
                        externalAccountId,
                        metaTokenId,
                        accessToken
                    }
                });
                console.log(`[DEBUG selectAccount] Create successful. New externalAccountId in DB:`, created.externalAccountId);
            }
            console.log(`[DEBUG selectAccount] Sending success response for ID:`, externalAccountId);
            res.json({ message: 'Account selected successfully', externalAccountId });
        }
        catch (e) {
            console.error('Select Account Error:', e.message);
            res.status(500).json({ message: 'Failed to select account', error: e.message });
        }
    });
}
function disconnectAccount(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const { clientId, platform } = req.body;
        if (!clientId || !platform)
            return res.status(400).send('clientId and platform are required');
        try {
            yield prisma_1.default.marketingAccount.deleteMany({
                where: { clientId, platform }
            });
            res.json({ message: 'Account disconnected successfully' });
        }
        catch (e) {
            console.error('Disconnect Error:', e.message);
            res.status(500).json({ message: 'Failed to disconnect account', error: e.message });
        }
    });
}
exports.middleware = [featureEnabled];
// ==== META LEADS ====
function getLeads(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const { clientId, from, to } = req.query;
        try {
            const whereClause = {};
            if (clientId) {
                whereClause.client_id = clientId;
            }
            if (from || to) {
                const dateFilter = {};
                if (from)
                    dateFilter.gte = new Date(from);
                if (to) {
                    const toDate = new Date(to);
                    toDate.setHours(23, 59, 59, 999);
                    dateFilter.lte = toDate;
                }
                whereClause.date = dateFilter;
            }
            if (req.query.groupId) {
                whereClause.group_id = req.query.groupId;
            }
            else if (req.query.campaignId) {
                // Support legacy or specific campaign filtering
                whereClause.campaignId = req.query.campaignId;
            }
            const leads = yield prisma_1.default.lead.findMany({
                where: whereClause,
                orderBy: { date: 'desc' },
                include: {
                    marketingCampaign: { select: { name: true } },
                    follow_ups: { orderBy: { date: 'desc' } },
                    aiScore: true
                }
            });
            res.json(leads);
        }
        catch (e) {
            console.error('getLeads error:', e.message);
            res.status(500).json({ message: 'Failed to fetch leads', error: e.message });
        }
    });
}
function createLead(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const { clientId, name, phone, email, location, campaign_name, campaignId, quality, status } = req.body;
        if (!clientId)
            return res.status(400).json({ message: 'clientId is required' });
        try {
            const lead = yield prisma_1.default.lead.create({
                data: {
                    client_id: clientId,
                    source: 'MANUAL',
                    name,
                    phone,
                    email,
                    location,
                    campaign_name,
                    campaignId: campaignId || null,
                    group_id: req.body.group_id || null, // Allow manual group override
                    quality: quality || 'MEDIUM',
                    status: status || 'NEW',
                    date: new Date()
                }
            });
            // AUTO-ASSIGN GROUP IF CAMPAIGN IS SELECTED
            if (campaignId && !req.body.group_id) {
                const camp = yield prisma_1.default.marketingCampaign.findUnique({ where: { id: campaignId } });
                if (camp === null || camp === void 0 ? void 0 : camp.group_id) {
                    yield prisma_1.default.lead.update({
                        where: { id: lead.id },
                        data: { group_id: camp.group_id }
                    });
                }
            }
            // Trigger AI Scoring asynchronously
            aiSalesEngine_service_1.AiSalesEngineService.calculateLeadScore(lead.id).catch(err => console.error('AI Lead Scoring Error:', err));
            res.json(lead);
        }
        catch (e) {
            console.error('createLead error:', e.message);
            res.status(500).json({ message: 'Failed to create lead', error: e.message });
        }
    });
}
function updateLeadFeedback(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const { id } = req.params;
        const { feedback } = req.body; // 'POSITIVE', 'NEGATIVE', or null
        try {
            const updated = yield prisma_1.default.lead.update({
                where: { id },
                data: { feedback }
            });
            res.json(updated);
        }
        catch (e) {
            console.error('updateLeadFeedback error:', e.message);
            res.status(500).json({ message: 'Failed to update feedback', error: e.message });
        }
    });
}
function updateLead(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const { id } = req.params;
        const data = req.body;
        try {
            const lead = yield prisma_1.default.lead.update({
                where: { id },
                data: Object.assign(Object.assign({}, data), { updatedAt: new Date() })
            });
            // Trigger AI Scoring asynchronously
            aiSalesEngine_service_1.AiSalesEngineService.calculateLeadScore(lead.id).catch(err => console.error('AI Lead Scoring Error:', err));
            res.json(lead);
        }
        catch (e) {
            console.error('updateLead error:', e.message);
            res.status(500).json({ message: 'Failed to update lead', error: e.message });
        }
    });
}
function deleteLead(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const { id } = req.params;
        try {
            yield prisma_1.default.lead.delete({ where: { id } });
            res.json({ message: 'Lead deleted successfully' });
        }
        catch (e) {
            console.error('deleteLead error:', e.message);
            res.status(500).json({ message: 'Failed to delete lead', error: e.message });
        }
    });
}
function addFollowUp(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const { leadId, status, notes, channel } = req.body;
        if (!leadId)
            return res.status(400).json({ message: 'leadId is required' });
        try {
            // Get current follow up count for this lead
            const count = yield prisma_1.default.leadFollowUp.count({ where: { lead_id: leadId } });
            const followUp = yield prisma_1.default.leadFollowUp.create({
                data: {
                    lead_id: leadId,
                    status,
                    notes,
                    channel: channel || 'Phone Call',
                    follow_up_number: count + 1,
                    date: new Date()
                }
            });
            // Also update the main lead status if provided
            if (status) {
                yield prisma_1.default.lead.update({
                    where: { id: leadId },
                    data: { status, updatedAt: new Date() }
                });
            }
            // Trigger AI Scoring asynchronously after followup
            aiSalesEngine_service_1.AiSalesEngineService.calculateLeadScore(leadId).catch(err => console.error('AI Lead Scoring Error:', err));
            res.json(followUp);
        }
        catch (e) {
            console.error('addFollowUp error:', e.message);
            res.status(500).json({ message: 'Failed to add follow up', error: e.message });
        }
    });
}
function syncLeads(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const { clientId } = req.body;
        if (!clientId)
            return res.status(400).json({ message: 'clientId is required' });
        try {
            const account = yield prisma_1.default.marketingAccount.findFirst({
                where: {
                    clientId,
                    platform: 'meta',
                    OR: [
                        { accessToken: { not: null } },
                        { metaTokenId: { not: null } }
                    ]
                }
            });
            if (!account) {
                return res.status(404).json({ message: 'No connected Meta account or profile found for this client' });
            }
            const result = yield metaLeadsService.syncLeads(clientId, account.externalAccountId);
            res.json(Object.assign({ message: 'Leads synced successfully' }, result));
        }
        catch (e) {
            console.error('syncLeads error:', e.message);
            res.status(500).json({ message: 'Failed to sync leads', error: e.message });
        }
    });
}
// ==========================================
// META ADS MANAGER EXTENSIONS
// ==========================================
function getMetaCampaignsDetailed(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { accountId } = req.query;
            if (!accountId)
                return res.status(400).json({ message: 'accountId is required' });
            const campaigns = yield metaService.fetchCampaignsDetailed(accountId);
            res.json(campaigns);
        }
        catch (error) {
            res.status(500).json({ message: 'Error fetching campaigns', error: error.message });
        }
    });
}
function getMetaAdSets(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { campaignId, accountId } = req.query;
            if (!campaignId || !accountId)
                return res.status(400).json({ message: 'campaignId and accountId are required' });
            const adSets = yield metaService.fetchAdSets(campaignId, accountId);
            res.json(adSets);
        }
        catch (error) {
            res.status(500).json({ message: 'Error fetching adsets', error: error.message });
        }
    });
}
function getMetaAds(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { adSetId, accountId } = req.query;
            if (!adSetId || !accountId)
                return res.status(400).json({ message: 'adSetId and accountId are required' });
            const ads = yield metaService.fetchAds(adSetId, accountId);
            res.json(ads);
        }
        catch (error) {
            res.status(500).json({ message: 'Error fetching ads', error: error.message });
        }
    });
}
function createMetaCampaign(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { accountId, name, objective, status } = req.body;
            if (!accountId || !name || !objective)
                return res.status(400).json({ message: 'accountId, name, and objective are required' });
            const result = yield metaService.createCampaign(accountId, { name, objective, status });
            res.json(result);
        }
        catch (error) {
            res.status(500).json({ message: 'Error creating campaign', error: error.message });
        }
    });
}
function createMetaAdSet(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { accountId, payload } = req.body;
            if (!accountId || !payload)
                return res.status(400).json({ message: 'accountId and payload are required' });
            const result = yield metaService.createAdSet(accountId, payload);
            res.json(result);
        }
        catch (error) {
            res.status(500).json({ message: 'Error creating ad set', error: error.message });
        }
    });
}
function updateMetaStatus(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { objectId, accountId, status } = req.body;
            if (!objectId || !accountId || !status)
                return res.status(400).json({ message: 'objectId, accountId, and status are required' });
            const result = yield metaService.updateStatus(objectId, accountId, status);
            res.json(result);
        }
        catch (error) {
            res.status(500).json({ message: 'Error updating status', error: error.message });
        }
    });
}
function sendReport(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const file = req.file;
        if (!file) {
            return res.status(400).json({ message: 'No PDF file uploaded.' });
        }
        const { clientId } = req.body;
        if (!clientId) {
            return res.status(400).json({ message: 'clientId is required.' });
        }
        try {
            const client = yield prisma_1.default.client.findUnique({
                where: { id: clientId },
                select: { name: true, contact_number: true }
            });
            if (!client || !client.contact_number) {
                return res.status(404).json({ message: 'Client not found or has no contact number registered.' });
            }
            const { waEngine } = yield Promise.resolve().then(() => __importStar(require('../whatsapp/WhatsAppEngine')));
            if (waEngine.status !== 'CONNECTED') {
                return res.status(503).json({ message: `WhatsApp engine is not connected (status: ${waEngine.status}). Please connect in Settings > WhatsApp.` });
            }
            const filename = `Qixads Report ${(0, date_fns_1.format)(new Date(), 'dd-MM-yyyy')}.pdf`;
            const sent = yield waEngine.sendDocument(client.contact_number, file.path, filename);
            const fsPromises = yield Promise.resolve().then(() => __importStar(require('fs/promises')));
            yield fsPromises.unlink(file.path).catch(() => { });
            if (sent) {
                res.json({ message: `Report sent to ${client.name} via WhatsApp.` });
            }
            else {
                res.status(500).json({ message: 'WhatsApp dispatch failed. Please check the connection.' });
            }
        }
        catch (error) {
            try {
                const fsPromises = yield Promise.resolve().then(() => __importStar(require('fs/promises')));
                if (file === null || file === void 0 ? void 0 : file.path)
                    yield fsPromises.unlink(file.path).catch(() => { });
            }
            catch (_) { }
            console.error('[sendReport] Error:', error);
            res.status(500).json({ message: 'Failed to send report.', error: error.message });
        }
    });
}
