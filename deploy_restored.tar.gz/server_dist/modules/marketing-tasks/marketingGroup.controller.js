"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.unassignCampaignFromGroup = exports.assignCampaignsToGroup = exports.deleteGroup = exports.updateGroup = exports.createGroup = exports.getGroups = void 0;
const prisma_1 = __importDefault(require("../../utils/prisma"));
const getGroups = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { clientId } = req.query;
        const where = {};
        if (clientId)
            where.client_id = clientId;
        const groups = yield prisma_1.default.marketingGroup.findMany({
            where,
            include: {
                _count: {
                    select: { campaigns: true, leads: true }
                }
            },
            orderBy: { createdAt: 'desc' }
        });
        res.json(groups);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
exports.getGroups = getGroups;
const createGroup = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { name, client_id } = req.body;
        if (!name || !client_id) {
            return res.status(400).json({ error: 'Name and Client ID are required' });
        }
        const group = yield prisma_1.default.marketingGroup.create({
            data: { name, client_id }
        });
        res.status(201).json(group);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
exports.createGroup = createGroup;
const updateGroup = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { id } = req.params;
        const { name } = req.body;
        const group = yield prisma_1.default.marketingGroup.update({
            where: { id },
            data: { name }
        });
        res.json(group);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
exports.updateGroup = updateGroup;
const deleteGroup = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { id } = req.params;
        // Remove relationships before deleting? 
        // No, Prisma relation should be handled if we set it as optional.
        yield prisma_1.default.marketingGroup.delete({
            where: { id }
        });
        res.json({ success: true });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
exports.deleteGroup = deleteGroup;
const assignCampaignsToGroup = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { groupId, campaignIds } = req.body;
        if (!groupId || !Array.isArray(campaignIds)) {
            return res.status(400).json({ error: 'Group ID and Campaign IDs array are required' });
        }
        // Update all campaigns to this group
        yield prisma_1.default.marketingCampaign.updateMany({
            where: { id: { in: campaignIds } },
            data: { group_id: groupId }
        });
        // Also update any leads associated with these campaigns to this group
        yield prisma_1.default.lead.updateMany({
            where: { campaignId: { in: campaignIds } },
            data: { group_id: groupId }
        });
        res.json({ success: true, message: `Assigned ${campaignIds.length} campaigns and their leads to the group.` });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
exports.assignCampaignsToGroup = assignCampaignsToGroup;
const unassignCampaignFromGroup = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { campaignId } = req.body;
        if (!campaignId) {
            return res.status(400).json({ error: 'Campaign ID is required' });
        }
        // Unassign campaign
        yield prisma_1.default.marketingCampaign.update({
            where: { id: campaignId },
            data: { group_id: null }
        });
        // Also unassign leads derived from this campaign
        yield prisma_1.default.lead.updateMany({
            where: { campaignId: campaignId },
            data: { group_id: null }
        });
        res.json({ success: true, message: 'Campaign unassigned from group successfully.' });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
exports.unassignCampaignFromGroup = unassignCampaignFromGroup;
