"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const controller_1 = require("./controller");
const marketingGroup_controller_1 = require("./marketingGroup.controller");
const middleware_1 = require("../auth/middleware");
// Ensure temp upload dir exists
const uploadDir = path_1.default.join(process.cwd(), 'uploads', 'reports');
if (!fs_1.default.existsSync(uploadDir))
    fs_1.default.mkdirSync(uploadDir, { recursive: true });
const reportUpload = (0, multer_1.default)({ dest: uploadDir });
const router = (0, express_1.Router)();
// Apply feature flag middleware to all routes in this module
router.use(...controller_1.middleware);
// OAuth Endpoints (GET) - MUST NOT BE PROTECTED
router.get('/auth/meta', controller_1.authMeta);
router.get('/auth/meta/callback', controller_1.metaCallback);
router.get('/auth/google', controller_1.authGoogle);
router.get('/auth/google/callback', controller_1.googleCallback);
// Apply protection to all subsequent data routes
router.use(middleware_1.protect);
// Manual sync endpoints (POST)
router.post('/sync', controller_1.manualSync);
router.post('/sync/campaign', controller_1.syncCampaign);
// Status endpoints
router.get('/meta/status', controller_1.getMetaAccountStatus);
// Get metrics endpoint (GET)
router.get('/metrics', controller_1.getMetrics);
router.get('/ai-tips', controller_1.getAiTips);
// Grouping Endpoints
router.get('/groups', marketingGroup_controller_1.getGroups);
router.post('/groups', marketingGroup_controller_1.createGroup);
router.put('/groups/:id', marketingGroup_controller_1.updateGroup);
router.delete('/groups/:id', marketingGroup_controller_1.deleteGroup);
router.post('/groups/assign', marketingGroup_controller_1.assignCampaignsToGroup);
router.post('/groups/unassign', marketingGroup_controller_1.unassignCampaignFromGroup);
// Leads endpoints
router.get('/leads', controller_1.getLeads);
router.post('/leads', controller_1.createLead);
router.patch('/leads/:id', controller_1.updateLead);
router.patch('/leads/:id/feedback', controller_1.updateLeadFeedback);
router.delete('/leads/:id', controller_1.deleteLead);
router.post('/leads/sync', controller_1.syncLeads);
router.post('/leads/follow-up', controller_1.addFollowUp);
router.post('/leads/follow-up', controller_1.addFollowUp);
// Account Discovery & Selection (NEW)
router.get('/status', controller_1.getIntegrationStatus);
router.get('/accounts', controller_1.getAvailableAccounts);
router.post('/accounts/select', controller_1.selectAccount);
router.post('/accounts/disconnect', controller_1.disconnectAccount);
// Meta Profile Management (NEW)
router.get('/meta/profiles', controller_1.getMetaProfiles);
router.post('/meta/link-profile', controller_1.linkAccountToProfile);
router.get('/meta/accounts', controller_1.getAvailableAccounts);
// Meta Ads Manager Operations (NEW)
router.get('/meta/manager/campaigns', controller_1.getMetaCampaignsDetailed);
router.get('/meta/manager/adsets', controller_1.getMetaAdSets);
router.get('/meta/manager/ads', controller_1.getMetaAds);
router.post('/meta/manager/campaigns', controller_1.createMetaCampaign);
router.post('/meta/manager/adsets', controller_1.createMetaAdSet);
router.patch('/meta/manager/status', controller_1.updateMetaStatus);
// Report Generation & WhatsApp Dispatch
router.post('/report/send', reportUpload.single('pdf'), controller_1.sendReport);
exports.default = router;
