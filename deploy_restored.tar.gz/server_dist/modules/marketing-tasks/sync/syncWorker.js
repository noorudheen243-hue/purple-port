"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarketingSyncWorker = void 0;
const prisma_1 = __importDefault(require("../../../utils/prisma"));
const marketingNormalizer_1 = require("../normalizer/marketingNormalizer");
const metaAdsService_1 = require("../services/metaAdsService");
const googleAdsService_1 = require("../services/googleAdsService");
const metaLeadsService_1 = require("../services/metaLeadsService");
const metaService = new metaAdsService_1.MetaAdsService();
const googleService = new googleAdsService_1.GoogleAdsService();
const metaLeadsService = new metaLeadsService_1.MetaLeadsService();
class MarketingSyncWorker {
    /**
     * Syncs all campaigns and recent metrics for a specific client across all platforms
     */
    static syncClientCampaigns(clientId_1) {
        return __awaiter(this, arguments, void 0, function* (clientId, daysBack = 35) {
            console.log(`[SyncWorker] Starting full sync for client: ${clientId} (${daysBack} days back)`);
            // Find all accounts for this client
            const accounts = yield prisma_1.default.marketingAccount.findMany({
                where: { clientId }
            });
            for (const acc of accounts) {
                try {
                    let externalCampaigns = [];
                    if (acc.platform === 'meta') {
                        externalCampaigns = yield metaService.fetchCampaigns(acc.externalAccountId);
                    }
                    else if (acc.platform === 'google') {
                        externalCampaigns = yield googleService.fetchCampaigns(acc.externalAccountId);
                    }
                    // Sync Campaign Metadata
                    for (const ext of externalCampaigns) {
                        const extId = ext.id.toString();
                        const existing = yield prisma_1.default.marketingCampaign.findFirst({
                            where: { externalCampaignId: extId, platform: acc.platform }
                        });
                        // Meta budgets are usually in minor units (e.g. cents)
                        let budgetValue = parseFloat(ext.daily_budget || ext.lifetime_budget || '0');
                        if (acc.platform === 'meta' && budgetValue > 0) {
                            budgetValue = budgetValue / 100;
                        }
                        const data = {
                            clientId: acc.clientId,
                            platform: acc.platform,
                            externalCampaignId: extId,
                            name: ext.name,
                            status: ext.effective_status || ext.status || 'UNKNOWN',
                            objective: ext.objective || 'UNKNOWN',
                            budget: budgetValue,
                            bid_strategy: ext.bid_strategy,
                            startDate: ext.start_time ? new Date(ext.start_time) : null,
                            ends: ext.stop_time ? new Date(ext.stop_time) : null
                        };
                        if (!existing) {
                            yield prisma_1.default.marketingCampaign.create({ data });
                        }
                        else {
                            yield prisma_1.default.marketingCampaign.update({
                                where: { id: existing.id },
                                data
                            });
                        }
                    }
                    // Sync Metrics for these campaigns
                    const dbCampaigns = yield prisma_1.default.marketingCampaign.findMany({
                        where: { clientId, platform: acc.platform }
                    });
                    const today = new Date();
                    const startDate = new Date();
                    startDate.setDate(today.getDate() - (daysBack - 1));
                    for (const camp of dbCampaigns) {
                        yield this.syncCampaignMetrics(camp.id, acc.externalAccountId, acc.platform, startDate, today);
                    }
                    // Sync Leads for Meta
                    if (acc.platform === 'meta') {
                        yield metaLeadsService.syncLeads(clientId, acc.externalAccountId);
                    }
                }
                catch (err) {
                    console.error(`[SyncWorker] Account sync failed for ${acc.externalAccountId}:`, err.message);
                }
            }
        });
    }
    /**
     * Syncs metrics for a specific platform and campaign within a date range
     */
    static syncCampaignMetrics(campaignId, accountId, platform, from, to) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let externalData = [];
                // Get the external ID from the DB record
                const campRecord = yield prisma_1.default.marketingCampaign.findUnique({
                    where: { id: campaignId }
                });
                if (!campRecord) {
                    console.warn(`Campaign ${campaignId} not found in DB. Skipping sync.`);
                    return;
                }
                const externalId = campRecord.externalCampaignId;
                if (platform === 'meta') {
                    externalData = yield metaService.fetchMetrics(externalId, accountId, from, to);
                }
                else if (platform === 'google') {
                    externalData = yield googleService.fetchMetrics(externalId, accountId, from, to);
                }
                else {
                    throw new Error(`Unsupported platform: ${platform}`);
                }
                for (const raw of externalData) {
                    yield this.upsertNormalizedMetric(campaignId, marketingNormalizer_1.MarketingDataNormalizer.normalizeMetric(raw));
                }
            }
            catch (error) {
                console.error(`Error in syncCampaignMetrics:`, error.message);
            }
        });
    }
    /**
     * Specialized sync for a single campaign on-demand.
     * Fetches the last N days of data and performs a targeted update.
     * Returns the latest metric row after sync.
     */
    static syncSingleCampaign(campaignId_1) {
        return __awaiter(this, arguments, void 0, function* (campaignId, daysBack = 7) {
            console.log(`[SyncWorker] Single Sync requested for campaign: ${campaignId}`);
            const campaign = yield prisma_1.default.marketingCampaign.findUnique({
                where: { id: campaignId }
            });
            if (!campaign) {
                throw new Error('Campaign not found');
            }
            const account = yield prisma_1.default.marketingAccount.findFirst({
                where: { clientId: campaign.clientId, platform: campaign.platform }
            });
            if (!account) {
                throw new Error('Account linked to campaign not found');
            }
            const today = new Date();
            const startDate = new Date();
            startDate.setDate(today.getDate() - (daysBack - 1));
            startDate.setHours(0, 0, 0, 0);
            let externalMetrics = [];
            try {
                if (campaign.platform === 'meta') {
                    externalMetrics = yield metaService.fetchMetrics(campaign.externalCampaignId, account.externalAccountId, startDate, today);
                }
                else if (campaign.platform === 'google') {
                    externalMetrics = yield googleService.fetchMetrics(campaign.externalCampaignId, account.externalAccountId, startDate, today);
                }
                console.log(`[SyncWorker] Found ${externalMetrics.length} metrics for single sync of ${campaign.name}`);
                // Upsert metrics
                for (const metric of externalMetrics) {
                    yield this.upsertNormalizedMetric(campaign.id, marketingNormalizer_1.MarketingDataNormalizer.normalizeMetric(metric));
                }
                // Return the latest metric for immediate UI update
                return yield prisma_1.default.marketingMetric.findFirst({
                    where: { campaignId: campaign.id },
                    orderBy: { date: 'desc' }
                });
            }
            catch (error) {
                console.error(`[SyncWorker] Single Campaign Sync Failed for ${campaignId}:`, error.message);
                throw error;
            }
        });
    }
    static upsertNormalizedMetric(campaignId, normalized) {
        return __awaiter(this, void 0, void 0, function* () {
            if (isNaN(normalized.date.getTime())) {
                console.warn(`Skipping invalid date for campaign ${campaignId}`);
                return;
            }
            const gte = new Date(normalized.date);
            gte.setHours(0, 0, 0, 0);
            const lt = new Date(normalized.date);
            lt.setHours(23, 59, 59, 999);
            const existing = yield prisma_1.default.marketingMetric.findFirst({
                where: {
                    campaignId: campaignId,
                    date: {
                        gte: gte,
                        lt: lt
                    }
                }
            });
            if (existing) {
                yield prisma_1.default.marketingMetric.update({
                    where: { id: existing.id },
                    data: {
                        impressions: normalized.impressions,
                        clicks: normalized.clicks,
                        spend: normalized.spend,
                        conversions: normalized.conversions,
                        reach: normalized.reach,
                        results: normalized.results,
                        results_cost: normalized.results_cost,
                        conversations: normalized.conversations,
                        messaging_conversations: normalized.messaging_conversations,
                        new_messaging_contacts: normalized.new_messaging_contacts,
                        purchases: normalized.purchases,
                        cost_per_purchase: normalized.cost_per_purchase,
                        ctr: normalized.ctr,
                        cpc: normalized.cpc,
                        cpm: normalized.cpm
                    }
                });
            }
            else {
                yield prisma_1.default.marketingMetric.create({
                    data: {
                        campaignId: campaignId,
                        date: normalized.date,
                        impressions: normalized.impressions,
                        clicks: normalized.clicks,
                        spend: normalized.spend,
                        conversions: normalized.conversions,
                        reach: normalized.reach,
                        results: normalized.results,
                        results_cost: normalized.results_cost,
                        conversations: normalized.conversations,
                        messaging_conversations: normalized.messaging_conversations,
                        new_messaging_contacts: normalized.new_messaging_contacts,
                        purchases: normalized.purchases,
                        cost_per_purchase: normalized.cost_per_purchase,
                        ctr: normalized.ctr,
                        cpc: normalized.cpc,
                        cpm: normalized.cpm
                    }
                });
            }
        });
    }
    /**
     * Main entry point for cron job to sync all active campaigns
     * @param daysBack - Number of days of history to sync. Defaults to 2 (yesterday and today).
     */
    static syncAllActiveCampaigns() {
        return __awaiter(this, arguments, void 0, function* (daysBack = 7) {
            var _a, _b, _c, _d, _e, _f;
            const syncErrors = []; // Collect account-level errors to persist in logs
            const log = yield prisma_1.default.marketingSyncLog.create({
                data: {
                    platform: 'ALL',
                    status: 'IN_PROGRESS',
                }
            });
            try {
                const today = new Date();
                const startDate = new Date(today);
                startDate.setDate(startDate.getDate() - (daysBack - 1)); // -1 because today is inclusive
                console.log(`[SyncWorker] Starting sync for the last ${daysBack} day(s) (from: ${startDate.toISOString().split('T')[0]})`);
                // Step 1: Discover New Campaigns for all linked accounts
                const allAccounts = yield prisma_1.default.marketingAccount.findMany({
                    where: {
                        OR: [
                            { accessToken: { not: null } },
                            { metaTokenId: { not: null } }
                        ]
                    }
                });
                console.log(`[SyncWorker] Found ${allAccounts.length} account(s) with tokens to sync:`, allAccounts.map((a) => `${a.platform}:${a.externalAccountId}`));
                for (const acc of allAccounts) {
                    try {
                        console.log(`[SyncWorker] Processing account: ${acc.platform}:${acc.externalAccountId} for client: ${acc.clientId}`);
                        let externalCampaigns = [];
                        if (acc.platform === 'meta') {
                            // Reset all campaigns for this account to prevent ghost ACTIVE statuses
                            yield prisma_1.default.marketingCampaign.updateMany({
                                where: { platform: 'meta', clientId: acc.clientId },
                                data: { status: 'UNKNOWN' }
                            });
                            // PURGE REMOVED: Relying on upsertNormalizedMetric below to handle updates for the sync window.
                            // This prevents wipes if the API call below fails or returns empty.
                            externalCampaigns = yield metaService.fetchCampaigns(acc.externalAccountId);
                        }
                        else if (acc.platform === 'google') {
                            yield prisma_1.default.marketingCampaign.updateMany({
                                where: { platform: 'google', clientId: acc.clientId },
                                data: { status: 'UNKNOWN' }
                            });
                            externalCampaigns = yield googleService.fetchCampaigns(acc.externalAccountId);
                        }
                        for (const ext of externalCampaigns) {
                            const campId = ext.id.toString();
                            const existing = yield prisma_1.default.marketingCampaign.findFirst({
                                where: { externalCampaignId: campId, platform: acc.platform }
                            });
                            if (!existing) {
                                yield prisma_1.default.marketingCampaign.create({
                                    data: {
                                        clientId: acc.clientId,
                                        platform: acc.platform,
                                        externalCampaignId: campId,
                                        name: ext.name,
                                        status: ext.effective_status || ext.status || 'UNKNOWN',
                                        objective: ext.objective || 'UNKNOWN',
                                        budget: parseFloat(ext.daily_budget || ext.lifetime_budget || '0') / 100,
                                        bid_strategy: ext.bid_strategy,
                                        attribution_setting: ((_b = (_a = ext.attribution_spec) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.attribution_window) || ((_c = ext.pacing_type) === null || _c === void 0 ? void 0 : _c[0]) || null,
                                        startDate: (ext.start_time || ext.startDate) ? new Date(ext.start_time || ext.startDate) : null,
                                        ends: (ext.stop_time || ext.end_date || ext.endDate) ? new Date(ext.stop_time || ext.end_date || ext.endDate) : null
                                    }
                                });
                                console.log(`[SyncWorker] Created new campaign: ${ext.name} (${campId})`);
                            }
                            else {
                                // Update name/status/metadata if changed
                                yield prisma_1.default.marketingCampaign.update({
                                    where: { id: existing.id },
                                    data: {
                                        name: ext.name,
                                        status: ext.effective_status || ext.status || 'UNKNOWN',
                                        budget: parseFloat(ext.daily_budget || ext.lifetime_budget || '0') / 100,
                                        bid_strategy: ext.bid_strategy,
                                        attribution_setting: ((_e = (_d = ext.attribution_spec) === null || _d === void 0 ? void 0 : _d[0]) === null || _e === void 0 ? void 0 : _e.attribution_window) || ((_f = ext.pacing_type) === null || _f === void 0 ? void 0 : _f[0]) || null,
                                        startDate: (ext.start_time || ext.startDate) ? new Date(ext.start_time || ext.startDate) : null,
                                        ends: (ext.stop_time || ext.end_date || ext.endDate) ? new Date(ext.stop_time || ext.end_date || ext.endDate) : null
                                    }
                                });
                                console.log(`[SyncWorker] Updated metadata for campaign: ${ext.name} (${campId})`);
                            }
                        }
                    }
                    catch (discErr) {
                        const errMsg = `Discovery failed for account ${acc.externalAccountId}: ${discErr.message}`;
                        console.error(errMsg);
                        syncErrors.push(errMsg);
                    }
                }
                // Step 2: Sync Metrics
                let successCount = 0;
                for (const acc of allAccounts) {
                    // Determine if we process it with bulk or per-campaign
                    if (acc.platform === 'meta') {
                        try {
                            console.log(`[SyncWorker] Fetching bulk metrics for Meta account: ${acc.externalAccountId}`);
                            // Chunk fetching month by month to prevent OOM
                            let currentStart = new Date(startDate);
                            let finalEnd = new Date(today);
                            while (currentStart <= finalEnd) {
                                let currentEnd = new Date(currentStart);
                                currentEnd.setMonth(currentEnd.getMonth() + 1);
                                if (currentEnd > finalEnd)
                                    currentEnd = finalEnd;
                                console.log(`[SyncWorker] Fetching chunk: ${currentStart.toISOString()} to ${currentEnd.toISOString()}`);
                                const accountMetrics = yield metaService.fetchAccountMetricsByCampaign(acc.externalAccountId, currentStart, currentEnd);
                                // Group by campaign_id
                                const metricsByCampaign = new Map();
                                for (const row of accountMetrics) {
                                    if (!metricsByCampaign.has(row.campaign_id)) {
                                        metricsByCampaign.set(row.campaign_id, []);
                                    }
                                    metricsByCampaign.get(row.campaign_id).push(row);
                                }
                                for (const [extCampaignId, rows] of metricsByCampaign.entries()) {
                                    let campRecord = yield prisma_1.default.marketingCampaign.findFirst({
                                        where: { externalCampaignId: extCampaignId, platform: 'meta' }
                                    });
                                    if (!campRecord) {
                                        campRecord = yield prisma_1.default.marketingCampaign.create({
                                            data: {
                                                clientId: acc.clientId,
                                                platform: acc.platform,
                                                externalCampaignId: extCampaignId,
                                                name: rows[0].campaign_name || 'Unknown Campaign',
                                                status: 'UNKNOWN',
                                                objective: 'UNKNOWN'
                                            }
                                        });
                                    }
                                    // Batch database writes to prevent SQLite locks
                                    console.log(`[SyncWorker] Found ${rows.length} metric rows for campaign: ${extCampaignId}`);
                                    for (let i = 0; i < rows.length; i++) {
                                        yield this.upsertNormalizedMetric(campRecord.id.toString(), marketingNormalizer_1.MarketingDataNormalizer.normalizeMetric(rows[i]));
                                        // Yield thread every 50 records to prevent SQLite locking
                                        if (i % 50 === 0) {
                                            yield new Promise(resolve => setTimeout(resolve, 5));
                                        }
                                    }
                                    successCount++;
                                }
                                // Advance the exact offset
                                currentStart = new Date(currentEnd);
                                currentStart.setDate(currentStart.getDate() + 1);
                            }
                        }
                        catch (err) {
                            const errMsg = `Failed bulk sync for Meta account ${acc.externalAccountId}: ${err.message}`;
                            console.error(errMsg);
                            syncErrors.push(errMsg);
                        }
                    }
                    else if (acc.platform === 'google') {
                        // Sync Per-Campaign for Google
                        const targetGoogleCampaigns = yield prisma_1.default.marketingCampaign.findMany({
                            where: {
                                clientId: acc.clientId,
                                platform: 'google',
                                status: { in: ['ACTIVE', 'ENABLED', 'PAUSED', 'ARCHIVED'] }
                            }
                        });
                        for (const camp of targetGoogleCampaigns) {
                            try {
                                yield this.syncCampaignMetrics(camp.id.toString(), acc.externalAccountId, camp.platform, startDate, today);
                                successCount++;
                            }
                            catch (err) {
                                console.error(`Failed to sync campaign ${camp.id}`, err);
                            }
                        }
                    }
                }
                // Step 3: Automated Lead Sync for all Meta Accounts
                console.log(`[SyncWorker] Starting automated lead sync for ${allAccounts.filter((a) => a.platform === 'meta').length} Meta account(s)`);
                for (const acc of allAccounts) {
                    if (acc.platform === 'meta') {
                        try {
                            yield metaLeadsService.syncLeads(acc.clientId, acc.externalAccountId);
                        }
                        catch (leadErr) {
                            console.error(`Lead sync failed for account ${acc.externalAccountId}:`, leadErr);
                        }
                    }
                }
                yield prisma_1.default.marketingSyncLog.update({
                    where: { id: log.id },
                    data: {
                        status: 'SUCCESS',
                        finishedAt: new Date(),
                        details: `Successfully synced ${successCount} campaigns. ${syncErrors.length > 0 ? 'Errors encountered: ' + syncErrors.join(' | ') : ''}`
                    }
                });
            }
            catch (overallError) {
                yield prisma_1.default.marketingSyncLog.update({
                    where: { id: log.id },
                    data: {
                        status: 'FAILED',
                        finishedAt: new Date(),
                        details: overallError.message
                    }
                });
            }
        });
    }
}
exports.MarketingSyncWorker = MarketingSyncWorker;
