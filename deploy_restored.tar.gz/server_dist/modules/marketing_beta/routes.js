"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller = __importStar(require("./controller"));
const middleware_1 = require("../auth/middleware");
const router = (0, express_1.Router)();
// Developer Admin Guard
const requireDevAdmin = (req, res, next) => {
    var _a, _b, _c;
    const userRole = (_a = req.user) === null || _a === void 0 ? void 0 : _a.role;
    const userEmail = ((_b = req.user) === null || _b === void 0 ? void 0 : _b.email) || ((_c = req.user) === null || _c === void 0 ? void 0 : _c.id); // In case we need better lookup later
    // Based on user request, explicitly allow only Developer Admin
    // For safety since email isn't in token natively, we allow DEV_ADMIN role fallback.
    if (userRole === 'DEVELOPER_ADMIN' || userRole === 'DEV_ADMIN') {
        return next();
    }
    return res.status(403).json({ message: 'Forbidden: Developer Admin access only.' });
};
router.use(middleware_1.protect);
router.use(requireDevAdmin);
router.get('/campaigns', controller.getCampaigns);
router.post('/campaigns/sync', controller.syncCampaigns);
router.get('/insights', controller.getInsights);
router.get('/automations', controller.getAutomations);
router.get('/groups', controller.getGroups);
exports.default = router;
