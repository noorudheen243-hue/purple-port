"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMarketingGroups = exports.getBetaAutomations = exports.getBetaInsights = exports.getBetaCampaigns = exports.syncBetaCampaigns = void 0;
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
const syncBetaCampaigns = (clientId) => __awaiter(void 0, void 0, void 0, function* () {
    // 1. Fetch campaigns from the main MarketingCampaign table safely (or Meta Ads directly)
    // To ensure idempotency and safety, we clone them to the beta table
    const existingCampaigns = yield prisma.marketingCampaign.findMany({
        where: clientId ? { clientId } : undefined
    });
    // 2. Iterate and upsert into the Beta table safely
    for (const campaign of existingCampaigns) {
        yield prisma.marketingCampaignBeta.upsert({
            where: { external_campaign_id: campaign.externalCampaignId },
            update: {
                start_date: campaign.startDate,
                end_date: campaign.ends,
                clientId: campaign.clientId,
                groupId: campaign.group_id,
            },
            create: {
                external_campaign_id: campaign.externalCampaignId,
                campaign_name: campaign.name,
                status: campaign.status || 'ACTIVE',
                spend: campaign.budget || 0,
                results: 0,
                start_date: campaign.startDate,
                end_date: campaign.ends,
                clientId: campaign.clientId,
                groupId: campaign.group_id,
            }
        });
    }
    // Create an Automation Log for the sync
    yield prisma.automationLogBeta.create({
        data: {
            trigger_event: 'MANUAL_SYNC',
            action_suggested: 'System updated campaign lists from Meta Ads.',
            related_entity_type: 'SYSTEM',
            related_entity_id: 'N/A'
        }
    });
    // 3. Scan for anomalies (AI intelligence Mock)
    const betaCampaigns = yield prisma.marketingCampaignBeta.findMany();
    for (const bCamp of betaCampaigns) {
        if (bCamp.spend > 1000 && bCamp.results < 5) {
            // Check if insight already exists to avoid spamming
            const existingAlert = yield prisma.aiInsightBeta.findFirst({
                where: { campaign_id: bCamp.id, type: 'ANOMALY' }
            });
            if (!existingAlert) {
                yield prisma.aiInsightBeta.create({
                    data: {
                        campaign_id: bCamp.id,
                        type: 'ANOMALY',
                        message: `High spend detected with low results on campaign: ${bCamp.campaign_name}`,
                    }
                });
                yield prisma.automationLogBeta.create({
                    data: {
                        trigger_event: 'AI_ANOMALY_DETECTED',
                        action_suggested: 'Alerted admin about underperforming campaign constraints.',
                        related_entity_type: 'CAMPAIGN',
                        related_entity_id: bCamp.id
                    }
                });
            }
        }
    }
    return { success: true, count: existingCampaigns.length };
});
exports.syncBetaCampaigns = syncBetaCampaigns;
const getBetaCampaigns = (clientId, groupId) => __awaiter(void 0, void 0, void 0, function* () {
    if (!clientId)
        return [];
    return yield prisma.marketingCampaignBeta.findMany({
        where: {
            clientId,
            groupId: groupId || undefined
        },
        orderBy: { createdAt: 'desc' }
    });
});
exports.getBetaCampaigns = getBetaCampaigns;
const getBetaInsights = (clientId) => __awaiter(void 0, void 0, void 0, function* () {
    return yield prisma.aiInsightBeta.findMany({
        where: clientId ? { campaign: { clientId } } : undefined,
        include: { campaign: true },
        orderBy: { createdAt: 'desc' },
        take: 50
    });
});
exports.getBetaInsights = getBetaInsights;
const getBetaAutomations = (clientId) => __awaiter(void 0, void 0, void 0, function* () {
    return yield prisma.automationLogBeta.findMany({
        where: clientId ? {
            OR: [
                { related_entity_type: 'CAMPAIGN', related_entity_id: { in: (yield prisma.marketingCampaignBeta.findMany({ where: { clientId }, select: { id: true } })).map(c => c.id) } },
                { related_entity_type: 'SYSTEM' } // Show system logs to everyone for now, or filter by logic
            ]
        } : undefined,
        orderBy: { createdAt: 'desc' },
        take: 50
    });
});
exports.getBetaAutomations = getBetaAutomations;
const getMarketingGroups = (clientId) => __awaiter(void 0, void 0, void 0, function* () {
    return yield prisma.marketingGroup.findMany({
        where: { client_id: clientId },
        orderBy: { name: 'asc' }
    });
});
exports.getMarketingGroups = getMarketingGroups;
