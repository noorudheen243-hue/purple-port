"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.batchUpdateAIRules = exports.updateAIRule = exports.sendTestWhatsApp = exports.getAIRules = exports.resolveAILog = exports.getAILogs = exports.updatePreferences = exports.getPreferences = exports.markAllRead = exports.markAsRead = exports.getMyNotifications = void 0;
const notificationService = __importStar(require("./service"));
const prisma_1 = __importDefault(require("../../utils/prisma"));
const axios_1 = __importDefault(require("axios"));
const WhatsAppEngine_1 = require("../whatsapp/WhatsAppEngine");
const getMyNotifications = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if (!req.user)
            throw new Error('Unauthorized');
        const notifications = yield notificationService.getUserNotifications(req.user.id);
        res.json(notifications);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
exports.getMyNotifications = getMyNotifications;
const markAsRead = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if (!req.user)
            throw new Error('Unauthorized');
        yield notificationService.markNotificationAsRead(req.params.id, req.user.id);
        res.json({ success: true });
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
exports.markAsRead = markAsRead;
const markAllRead = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if (!req.user)
            throw new Error('Unauthorized');
        yield notificationService.markAllAsRead(req.user.id);
        res.json({ success: true });
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
exports.markAllRead = markAllRead;
// --- SMART NOTIFICATION PREFERENCES & AI LOGS ---
const getPreferences = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if (!req.user)
            throw new Error('Unauthorized');
        const prefs = yield prisma_1.default.userNotificationPreference.findMany({
            where: { user_id: req.user.id }
        });
        res.json(prefs);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
exports.getPreferences = getPreferences;
const updatePreferences = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if (!req.user)
            throw new Error('Unauthorized');
        const { category, app_enabled, whatsapp_enabled } = req.body;
        const pref = yield prisma_1.default.userNotificationPreference.upsert({
            where: {
                user_id_category: { user_id: req.user.id, category }
            },
            update: { app_enabled, whatsapp_enabled },
            create: { user_id: req.user.id, category, app_enabled, whatsapp_enabled }
        });
        res.json(pref);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
exports.updatePreferences = updatePreferences;
const getAILogs = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if (!req.user)
            throw new Error('Unauthorized');
        const logs = yield prisma_1.default.aIAlertLog.findMany({
            where: { user_id: req.user.id, is_resolved: false },
            orderBy: { createdAt: 'desc' },
            take: 20
        });
        res.json(logs);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
exports.getAILogs = getAILogs;
const resolveAILog = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if (!req.user)
            throw new Error('Unauthorized');
        yield prisma_1.default.aIAlertLog.update({
            where: { id: req.params.id },
            data: { is_resolved: true }
        });
        res.json({ success: true });
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
exports.resolveAILog = resolveAILog;
// --- AI ALERT RULES (ADMIN) ---
const getAIRules = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        let rules = yield prisma_1.default.aINotificationRule.findMany({
            orderBy: { createdAt: 'asc' }
        });
        // AUTO-SEED IF EMPTY
        if (rules.length === 0) {
            console.log("🌱 Database: No AI Rules found. Seeding defaults...");
            const defaults = [
                { name: 'Task Overdue Level 1', trigger_type: 'TASK_DELAY', config_json: JSON.stringify({ threshold_days: 1 }), message_template: "Task '{task_name}' is pending beyond expected time. Please take action.", is_active: true },
                { name: 'Task Overdue Level 2 (Manager)', trigger_type: 'TASK_DELAY', config_json: JSON.stringify({ threshold_days: 3 }), message_template: "Urgent: '{task_name}' assigned to {staff_name} is delayed by {delay_days} days.", is_active: true },
                { name: 'Attendance Pattern Warning', trigger_type: 'ATTENDANCE_PATTERN', config_json: JSON.stringify({ threshold_count: 3, period_days: 7 }), message_template: "You have been marked late {late_count} times this week.", is_active: true },
                { name: 'Request Pending Alert', trigger_type: 'PENDING_REQUEST', config_json: JSON.stringify({ threshold_hours: 24 }), message_template: "A leave/regularization request by {staff_name} is pending for more than 24 hours.", is_active: true },
                { name: 'MoM Followup Alert', trigger_type: 'MEETING_FOLLOWUP', config_json: JSON.stringify({ threshold_hours: 24 }), message_template: "MoM for meeting '{meeting_title}' is pending over 24 hours.", is_active: true }
            ];
            yield prisma_1.default.aINotificationRule.createMany({
                data: defaults
            });
            rules = yield prisma_1.default.aINotificationRule.findMany();
        }
        res.json(rules);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
exports.getAIRules = getAIRules;
const sendTestWhatsApp = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c;
    try {
        const { phoneNumber, message } = req.body;
        const trackingId = `WA-${Math.random().toString(36).substring(2, 9).toUpperCase()}`;
        // ── PRIORITY 1: Use in-house WhatsApp Engine if connected ─────────────
        if (WhatsAppEngine_1.waEngine.status === 'CONNECTED') {
            console.log(`[WA ENGINE DISPATCH] Sending test to ${phoneNumber} via in-house engine`);
            const sent = yield WhatsAppEngine_1.waEngine.sendText(phoneNumber, message);
            if (sent) {
                return res.json({
                    success: true,
                    tracking_id: trackingId,
                    status: 'DELIVERED',
                    gateway: 'QIX_INTERNAL_ENGINE',
                    message: 'Test message dispatched via in-house WhatsApp Engine.'
                });
            }
            else {
                return res.status(500).json({
                    success: false,
                    message: 'Engine is connected but failed to dispatch. Check server logs.'
                });
            }
        }
        // ── PRIORITY 2: Third-party Gateway API ───────────────────────────────
        const settings = yield prisma_1.default.systemSetting.findMany({
            where: { key: { in: ['WHATSAPP_API_URL', 'WHATSAPP_API_TOKEN', 'WHATSAPP_ENABLED'] } }
        });
        const config = settings.reduce((acc, s) => {
            acc[s.key] = s.value;
            return acc;
        }, {});
        let apiEndpoint = config.WHATSAPP_API_URL || '';
        if (apiEndpoint.includes('ultramsg.com') && !apiEndpoint.endsWith('/messages/chat')) {
            apiEndpoint = apiEndpoint.replace(/\/+$/, '') + '/messages/chat';
        }
        if (config.WHATSAPP_ENABLED === 'true' && apiEndpoint && config.WHATSAPP_API_TOKEN) {
            console.log(`[WA LIVE GATEWAY] Attempting real dispatch via ${apiEndpoint}`);
            try {
                const headers = { 'Content-Type': 'application/json' };
                let body = {
                    to: phoneNumber,
                    body: message,
                    token: config.WHATSAPP_API_TOKEN,
                    phone: phoneNumber,
                    message: message,
                    apikey: config.WHATSAPP_API_TOKEN
                };
                // SPECIAL FORMAT FOR META CLOUD API
                if (apiEndpoint.includes('graph.facebook.com')) {
                    headers['Authorization'] = `Bearer ${config.WHATSAPP_API_TOKEN}`;
                    body = {
                        messaging_product: "whatsapp",
                        recipient_type: "individual",
                        to: phoneNumber,
                        type: "text",
                        text: { preview_url: false, body: message }
                    };
                }
                const resData = yield axios_1.default.post(apiEndpoint, body, { headers, timeout: 10000 });
                return res.json({
                    success: true,
                    tracking_id: trackingId,
                    status: 'DELIVERED',
                    gateway: 'LIVE_API_DISPATCH',
                    details: resData.data, // PROVIDE REAL FEEDBACK
                    message: "Real message successfully handed off to your WhatsApp provider."
                });
            }
            catch (apiErr) {
                console.error("[WA LIVE GATEWAY] API Error:", ((_a = apiErr.response) === null || _a === void 0 ? void 0 : _a.data) || apiErr.message);
                // ATTEMPT GET FALLBACK (some simple gateways)
                try {
                    console.log("[WA LIVE GATEWAY] Attempting GET Fallback...");
                    const gateUrl = new URL(config.WHATSAPP_API_URL);
                    gateUrl.searchParams.append("to", phoneNumber);
                    gateUrl.searchParams.append("body", message);
                    gateUrl.searchParams.append("token", config.WHATSAPP_API_TOKEN);
                    const resGet = yield axios_1.default.get(gateUrl.toString());
                    return res.json({
                        success: true,
                        tracking_id: trackingId,
                        status: 'DELIVERED (GET)',
                        gateway: 'LIVE_GATEWAY_V1',
                        details: resGet.data,
                        message: "Real message sent via HTTP GET fallback."
                    });
                }
                catch (getErr) {
                    return res.status(500).json({
                        success: false,
                        message: "Gateway API rejected the request.",
                        error: ((_c = (_b = apiErr.response) === null || _b === void 0 ? void 0 : _b.data) === null || _c === void 0 ? void 0 : _c.message) || apiErr.message,
                        hint: "Ensure your URL ends with /messages/chat for UltraMsg or similar endpoints."
                    });
                }
            }
        }
        // ── PRIORITY 3: Simulated (no engine, no gateway config) ─────────────
        console.log(`[WA MOCK LAYER] [${trackingId}] Engine: ${WhatsAppEngine_1.waEngine.status} | Target: ${phoneNumber}`);
        res.json({
            success: true,
            tracking_id: trackingId,
            status: 'SIMULATED',
            gateway: 'INTERNAL_MOCK_ENGINE',
            message: "Engine not connected and no Gateway API configured. Connect the WhatsApp Engine or add API credentials to dispatch real messages."
        });
    }
    catch (err) {
        res.status(500).json({ message: "Backend failure during trial dispatch." });
    }
});
exports.sendTestWhatsApp = sendTestWhatsApp;
const updateAIRule = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { id } = req.params;
        const { trigger_type, is_active, config_json, message_template, name } = req.body;
        const rule = yield prisma_1.default.aINotificationRule.upsert({
            where: { id: id || 'new-uuid' }, // This relies on client sending uuid or a fallback
            update: { trigger_type, is_active, config_json, message_template, name },
            create: { trigger_type, is_active, config_json, message_template, name }
        });
        res.json(rule);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
exports.updateAIRule = updateAIRule;
const batchUpdateAIRules = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { rules } = req.body; // Array of rules
        const results = yield Promise.all(rules.map((r) => prisma_1.default.aINotificationRule.upsert({
            where: { name: r.name },
            update: { trigger_type: r.trigger_type, is_active: r.is_active, config_json: r.config_json, message_template: r.message_template },
            create: { name: r.name, trigger_type: r.trigger_type, is_active: r.is_active, config_json: r.config_json, message_template: r.message_template }
        })));
        res.json(results);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
exports.batchUpdateAIRules = batchUpdateAIRules;
