"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendTestWhatsApp = void 0;
const prisma_1 = __importDefault(require("../../utils/prisma"));
const axios_1 = __importDefault(require("axios"));
// ... other controller functions (getMyNotifications, etc)
const sendTestWhatsApp = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { phoneNumber, message } = req.body;
        // Fetch real gateway config from DB
        const settings = yield prisma_1.default.systemSetting.findMany({
            where: { key: { in: ['WHATSAPP_API_URL', 'WHATSAPP_API_TOKEN', 'WHATSAPP_ENABLED'] } }
        });
        const config = settings.reduce((acc, s) => {
            acc[s.key] = s.value;
            return acc;
        }, {});
        const trackingId = `WA-LIVE-${Math.random().toString(36).substring(2, 9).toUpperCase()}`;
        if (config.WHATSAPP_ENABLED === 'true' && config.WHATSAPP_API_URL && config.WHATSAPP_API_TOKEN) {
            console.log(`[WA LIVE GATEWAY] Attempting real dispatch via ${config.WHATSAPP_API_URL}`);
            // Format for UltraMsg (common) or generic POST.
            // Using common param names: to, body, token
            try {
                yield axios_1.default.post(config.WHATSAPP_API_URL, {
                    to: phoneNumber,
                    body: message,
                    token: config.WHATSAPP_API_TOKEN,
                    // Fallback names for other providers
                    phone: phoneNumber,
                    message: message,
                    msg: message,
                    apikey: config.WHATSAPP_API_TOKEN
                }, { timeout: 10000 });
                return res.json({
                    success: true,
                    tracking_id: trackingId,
                    status: 'DELIVERED',
                    gateway: 'LIVE_API_DISPATCH',
                    message: "Real message successfully handed off to your WhatsApp provider."
                });
            }
            catch (apiErr) {
                console.error("[WA LIVE GATEWAY] API Error:", apiErr.message);
                return res.status(500).json({ success: false, message: "Gateway API rejected the request. Check your URL/Token." });
            }
        }
        // Fallback to Mock
        console.log(`[WA MOCK LAYER] [${trackingId}] Target: ${phoneNumber} | Msg: ${message}`);
        res.json({
            success: true,
            tracking_id: trackingId,
            status: 'SIMULATED',
            gateway: 'INTERNAL_MOCK_ENGINE',
            message: "Credentials missing. Message logged to server console only."
        });
    }
    catch (err) {
        res.status(500).json({ message: "Backend error during Trial Dispatch." });
    }
});
exports.sendTestWhatsApp = sendTestWhatsApp;
// ... rest of the controller (updateAIRule, etc)
