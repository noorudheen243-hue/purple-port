"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendSmartNotification = void 0;
const prisma_1 = __importDefault(require("../../utils/prisma"));
const whatsapp_service_1 = require("./whatsapp.service");
const service_1 = require("./service");
const sendSmartNotification = (userId, category, // ATTENDANCE, TASKS, PAYROLL, REQUESTS, MEETINGS
title, message, link) => __awaiter(void 0, void 0, void 0, function* () {
    // 1. Check User Preferences
    let appEnabled = true;
    let waEnabled = true;
    const prefs = yield prisma_1.default.userNotificationPreference.findUnique({
        where: {
            user_id_category: {
                user_id: userId,
                category: category
            }
        }
    });
    if (prefs) {
        appEnabled = prefs.app_enabled;
        waEnabled = prefs.whatsapp_enabled;
    }
    // 2. Deliver In-App Notice
    if (appEnabled) {
        try {
            yield (0, service_1.createNotification)(userId, category, message, link);
            yield prisma_1.default.notificationLog.create({
                data: {
                    user_id: userId,
                    channel: 'APP',
                    message,
                    status: 'SENT'
                }
            });
        }
        catch (e) {
            yield prisma_1.default.notificationLog.create({
                data: { user_id: userId, channel: 'APP', message, status: 'FAILED', error_message: e.message }
            });
        }
    }
    // 3. Deliver WhatsApp Notice
    if (waEnabled) {
        const success = yield (0, whatsapp_service_1.sendWhatsAppMessage)(userId, message);
        yield prisma_1.default.notificationLog.create({
            data: {
                user_id: userId,
                channel: 'WHATSAPP',
                message,
                status: success ? 'SENT' : 'FAILED'
            }
        });
    }
    return true;
});
exports.sendSmartNotification = sendSmartNotification;
