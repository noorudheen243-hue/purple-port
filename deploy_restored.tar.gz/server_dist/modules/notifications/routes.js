"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const controller_1 = require("./controller");
const middleware_1 = require("../auth/middleware");
const roles_1 = require("../auth/roles");
const router = express_1.default.Router();
router.use(middleware_1.protect);
router.get('/', controller_1.getMyNotifications);
router.put('/:id/read', controller_1.markAsRead);
router.put('/read-all', controller_1.markAllRead);
// AI & Preferences
router.get('/preferences', controller_1.getPreferences);
router.post('/preferences', controller_1.updatePreferences);
router.get('/ai-logs', controller_1.getAILogs);
router.put('/ai-logs/:id/resolve', controller_1.resolveAILog);
// AI Admin Rules 
router.get('/rules', (0, middleware_1.authorize)(roles_1.ROLES.ADMIN, roles_1.ROLES.DEVELOPER_ADMIN), controller_1.getAIRules);
router.post('/rules/batch', (0, middleware_1.authorize)(roles_1.ROLES.ADMIN, roles_1.ROLES.DEVELOPER_ADMIN), controller_1.batchUpdateAIRules);
router.post('/wa-test', (0, middleware_1.authorize)(roles_1.ROLES.ADMIN, roles_1.ROLES.DEVELOPER_ADMIN), controller_1.sendTestWhatsApp); // Added WA Trial/Test
exports.default = router;
