"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.dispatchWhatsAppText = exports.sendWhatsAppMessage = void 0;
const prisma_1 = __importDefault(require("../../utils/prisma"));
const axios_1 = __importDefault(require("axios"));
/**
 * Sends a WhatsApp TEXT message to a user by their user ID.
 * Priority: Custom WhatsApp Engine → DB Gateway Config → Mock fallback.
 */
const sendWhatsAppMessage = (userId, message) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b;
    try {
        const user = yield prisma_1.default.user.findUnique({
            where: { id: userId },
            include: { staffProfile: true }
        });
        if (!user)
            return false;
        const phone = ((_a = user.staffProfile) === null || _a === void 0 ? void 0 : _a.whatsapp_number) || ((_b = user.staffProfile) === null || _b === void 0 ? void 0 : _b.personal_contact);
        if (!phone)
            return false;
        return yield (0, exports.dispatchWhatsAppText)(phone, message);
    }
    catch (e) {
        console.error('[WhatsApp Service] sendWhatsAppMessage error:', e);
        return false;
    }
});
exports.sendWhatsAppMessage = sendWhatsAppMessage;
/**
 * Core dispatcher — routes through the internal Custom WhatsApp Engine first,
 * falls back to the DB-configured API gateway (legacy UltraMsg / Meta Cloud),
 * then falls back to mock logging.
 */
const dispatchWhatsAppText = (phone, message) => __awaiter(void 0, void 0, void 0, function* () {
    // ── 1. Try Internal Custom Engine ──────────────────────────────────────
    try {
        const { waEngine } = yield Promise.resolve().then(() => __importStar(require('../whatsapp/WhatsAppEngine')));
        if (waEngine.status === 'CONNECTED') {
            const sent = yield waEngine.sendText(phone, message);
            if (sent) {
                console.log(`[WhatsApp] ✅ [Custom Engine] Sent to ${phone}`);
                return true;
            }
        }
    }
    catch (_) {
        // Engine not initialized yet — fall through to API gateway
    }
    // ── 2. Try DB-configured API Gateway (legacy) ───────────────────────────
    const settings = yield prisma_1.default.systemSetting.findMany({
        where: { key: { in: ['WHATSAPP_API_URL', 'WHATSAPP_API_TOKEN', 'WHATSAPP_ENABLED'] } }
    });
    const config = settings.reduce((acc, s) => {
        acc[s.key] = s.value;
        return acc;
    }, {});
    if (config.WHATSAPP_ENABLED === 'true' && config.WHATSAPP_API_URL && config.WHATSAPP_API_TOKEN) {
        try {
            const apiEndpoint = config.WHATSAPP_API_URL;
            const headers = { 'Content-Type': 'application/json' };
            let body = {
                to: phone,
                body: message,
                token: config.WHATSAPP_API_TOKEN,
                phone: phone,
                message: message,
                apikey: config.WHATSAPP_API_TOKEN
            };
            if (apiEndpoint.includes('graph.facebook.com')) {
                headers['Authorization'] = `Bearer ${config.WHATSAPP_API_TOKEN}`;
                body = {
                    messaging_product: 'whatsapp',
                    recipient_type: 'individual',
                    to: phone,
                    type: 'text',
                    text: { preview_url: false, body: message }
                };
            }
            yield axios_1.default.post(apiEndpoint, body, { headers, timeout: 10000 });
            console.log(`[WhatsApp] ✅ [API Gateway] Sent to ${phone}`);
            return true;
        }
        catch (err) {
            console.error('[WhatsApp] API Gateway failed:', err.message);
            // GET fallback for simple gateways
            if (!config.WHATSAPP_API_URL.includes('graph.facebook.com')) {
                try {
                    const gateUrl = new URL(config.WHATSAPP_API_URL);
                    gateUrl.searchParams.append('to', phone);
                    gateUrl.searchParams.append('body', message);
                    gateUrl.searchParams.append('token', config.WHATSAPP_API_TOKEN);
                    yield axios_1.default.get(gateUrl.toString(), { timeout: 8000 });
                    return true;
                }
                catch (_) { }
            }
        }
    }
    // ── 3. Mock fallback ───────────────────────────────────────────────────
    console.log(`[WhatsApp - Mock] To ${phone}: "${message}"`);
    return true;
});
exports.dispatchWhatsAppText = dispatchWhatsAppText;
