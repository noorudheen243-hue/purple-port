"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.resetPassword = exports.deleteUser = exports.updateUser = exports.getUserById = exports.getUsers = void 0;
const userService = __importStar(require("./service"));
const getUsers = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const includeHidden = req.query.include_hidden === 'true';
        const users = yield userService.getAllUsers(includeHidden);
        res.json(users);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
exports.getUsers = getUsers;
const getUserById = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const user = yield userService.findUserById(req.params.id);
        if (!user) {
            res.status(404).json({ message: 'User not found' });
            return;
        }
        res.json(user);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
exports.getUserById = getUserById;
// ... (getUserById above)
// ... (previous code)
const updateUser = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { id } = req.params;
        const _a = req.body, { password } = _a, otherData = __rest(_a, ["password"]);
        // Map password to password_hash if present
        const updateData = Object.assign({}, otherData);
        if (password) {
            updateData.password_hash = password; // Service will hash this
        }
        const user = yield userService.updateUser(id, updateData);
        res.json(user);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
exports.updateUser = updateUser;
const deleteUser = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { id } = req.params;
        // 1. Fetch user to check Role
        const userToDelete = yield userService.findUserById(id);
        if (!userToDelete) {
            return res.status(404).json({ message: 'User not found' });
        }
        // 2. Prevent deleting Developer Admin
        if (userToDelete.role === 'DEVELOPER_ADMIN') {
            return res.status(403).json({ message: 'Cannot delete a Developer Admin user.' });
        }
        // 3. Perform Delete
        yield userService.deleteUser(id);
        res.json({ message: 'User deleted successfully' });
    }
    catch (error) {
        // Handle FK Constraint errors gracefully if possible
        if (error.code === 'P2003') { // Prisma FK violation
            return res.status(400).json({ message: 'Cannot delete user: They have associated records (Tasks, Clients, etc.).' });
        }
        res.status(500).json({ message: error.message });
    }
});
exports.deleteUser = deleteUser;
const resetPassword = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { id } = req.params;
        const { newPassword } = req.body;
        if (!newPassword || newPassword.length < 6) {
            return res.status(400).json({ message: 'Password must be at least 6 characters' });
        }
        // 1. Fetch user to verify they are not a CLIENT
        const targetUser = yield userService.findUserById(id);
        if (!targetUser) {
            return res.status(404).json({ message: 'User not found' });
        }
        if (targetUser.role === 'CLIENT') {
            return res.status(400).json({ message: 'Client passwords cannot be reset here.' });
        }
        // 2. Perform Update (Service handles hashing)
        yield userService.updateUser(id, { password_hash: newPassword });
        res.json({ message: `Password for ${targetUser.full_name} has been reset successfully.` });
    }
    catch (error) {
        console.error('Reset Password Error:', error);
        res.status(500).json({ message: error.message || 'Failed to reset password' });
    }
});
exports.resetPassword = resetPassword;
