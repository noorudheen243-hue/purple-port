"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.waEngine = exports.WhatsAppEngine = void 0;
const whatsapp_web_js_1 = require("whatsapp-web.js");
const child_process_1 = require("child_process");
const qrcode_1 = __importDefault(require("qrcode"));
class WhatsAppEngine {
    constructor() {
        this.client = null;
        this.status = 'DISCONNECTED';
        this.qrDataUrl = null;
        this.connectedNumber = null;
    }
    static getInstance() {
        if (!WhatsAppEngine.instance) {
            WhatsAppEngine.instance = new WhatsAppEngine();
        }
        return WhatsAppEngine.instance;
    }
    initialize() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.status === 'INITIALIZING' || this.status === 'CONNECTED') {
                console.log(`[WhatsApp Engine] Skip init: Status is ${this.status}`);
                return;
            }
            console.log('[WhatsApp Engine] Initializing V12 (Chrome Stable Force)...');
            this.status = 'INITIALIZING';
            // Set a timeout to prevent permanent "INITIALIZING" state
            const initTimeout = setTimeout(() => {
                if (this.status === 'INITIALIZING') {
                    console.error('[WhatsApp Engine] Initialization timed out after 120s. Resetting...');
                    this.hardReset();
                }
            }, 120000);
            try {
                const dataPath = process.platform === 'linux' ? '/var/www/purple-port/server/.wwebjs_auth' : './.wwebjs_auth';
                const chromePath = process.platform === 'linux' ? '/usr/bin/google-chrome-stable' : undefined;
                console.log(`[WhatsApp Engine] Launching browser at: ${chromePath || 'Default'}`);
                this.client = new whatsapp_web_js_1.Client({
                    authStrategy: new whatsapp_web_js_1.LocalAuth({
                        clientId: 'session',
                        dataPath: dataPath
                    }),
                    puppeteer: {
                        executablePath: chromePath,
                        headless: true,
                        args: [
                            '--no-sandbox',
                            '--disable-setuid-sandbox',
                            '--disable-dev-shm-usage',
                            '--disable-accelerated-2d-canvas',
                            '--no-first-run',
                            '--no-zygote',
                            '--disable-gpu',
                            '--disable-software-rasterizer',
                            '--disable-extensions',
                            '--disable-features=IsolateOrigins,site-per-process',
                            '--hide-scrollbars',
                            '--mute-audio',
                            '--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
                        ],
                    }
                });
                this.client.on('qr', (qr) => __awaiter(this, void 0, void 0, function* () {
                    clearTimeout(initTimeout);
                    try {
                        this.qrDataUrl = yield qrcode_1.default.toDataURL(qr);
                    }
                    catch (e) {
                        this.qrDataUrl = qr;
                    }
                    this.status = 'QR_READY';
                    console.log('[WhatsApp Engine] QR Code received and converted to data URL.');
                }));
                this.client.on('ready', () => {
                    var _a;
                    clearTimeout(initTimeout);
                    this.status = 'CONNECTED';
                    this.qrDataUrl = null;
                    this.connectedNumber = ((_a = this.client) === null || _a === void 0 ? void 0 : _a.info.wid.user) || null;
                    console.log('[WhatsApp Engine] SUCCESS: Connected as', this.connectedNumber);
                });
                this.client.on('authenticated', () => {
                    console.log('[WhatsApp Engine] Authentication successful.');
                });
                this.client.on('auth_failure', (msg) => {
                    console.error('[WhatsApp Engine] Auth failure:', msg);
                    this.hardReset();
                });
                this.client.on('disconnected', (reason) => {
                    console.warn('[WhatsApp Engine] Client disconnected:', reason);
                    this.status = 'DISCONNECTED';
                });
                console.log('[WhatsApp Engine] Starting client initialization...');
                yield this.client.initialize();
                console.log('[WhatsApp Engine] Browser process started.');
            }
            catch (err) {
                console.error('[WhatsApp Engine] Failed to initialize V12:', err.stack || err.message);
                this.status = 'FAILED';
                clearTimeout(initTimeout);
            }
        });
    }
    hardReset() {
        return __awaiter(this, void 0, void 0, function* () {
            console.log('[WhatsApp Engine] Hard reset triggered.');
            this.status = 'DISCONNECTED';
            this.qrDataUrl = null;
            if (this.client) {
                try {
                    yield this.client.destroy();
                }
                catch (e) { }
                this.client = null;
            }
            if (process.platform === 'linux') {
                try {
                    (0, child_process_1.execSync)('pkill -f chrome || true');
                }
                catch (e) { }
            }
            // Wait 15 seconds before retry
            setTimeout(() => this.initialize(), 15000);
        });
    }
    logout() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.client)
                return;
            try {
                yield this.client.logout();
                yield this.client.destroy();
            }
            catch (e) { }
            this.status = 'DISCONNECTED';
            this.client = null;
            this.qrDataUrl = null;
        });
    }
    formatNumber(phone) {
        let clean = phone.replace(/\D/g, '');
        if (clean.length === 10)
            clean = '91' + clean;
        return `${clean}@c.us`;
    }
    sendText(phone, text) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.status !== 'CONNECTED' || !this.client) {
                console.log('[WhatsApp Engine] Send aborted: Not connected.');
                return false;
            }
            try {
                const jid = this.formatNumber(phone);
                yield this.client.sendMessage(jid, text);
                return true;
            }
            catch (error) {
                console.error(`[WhatsApp Engine] Send error:`, error.message);
                if (error.message.includes('detached Frame') || error.message.includes('Target closed')) {
                    this.hardReset();
                }
                return false;
            }
        });
    }
    sendDocument(phone, filePath, filename) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.status !== 'CONNECTED' || !this.client)
                return false;
            try {
                const jid = this.formatNumber(phone);
                const media = whatsapp_web_js_1.MessageMedia.fromFilePath(filePath);
                yield this.client.sendMessage(jid, media, { caption: filename });
                return true;
            }
            catch (e) {
                return false;
            }
        });
    }
}
exports.WhatsAppEngine = WhatsAppEngine;
exports.waEngine = WhatsAppEngine.getInstance();
