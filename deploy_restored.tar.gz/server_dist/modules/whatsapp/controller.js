"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getStatus = getStatus;
exports.requestInitialization = requestInitialization;
exports.logout = logout;
const WhatsAppEngine_1 = require("./WhatsAppEngine");
function getStatus(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c;
        res.json({
            status: WhatsAppEngine_1.waEngine.status,
            qrUrl: WhatsAppEngine_1.waEngine.qrDataUrl,
            connectedNumber: WhatsAppEngine_1.waEngine.connectedNumber || ((_c = (_b = (_a = WhatsAppEngine_1.waEngine.client) === null || _a === void 0 ? void 0 : _a.info) === null || _b === void 0 ? void 0 : _b.wid) === null || _c === void 0 ? void 0 : _c.user)
        });
    });
}
function requestInitialization(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        if (WhatsAppEngine_1.waEngine.status === 'DISCONNECTED' || WhatsAppEngine_1.waEngine.status === 'QR_READY') {
            // Kick off the init process. It handles existing cache gracefully.
            WhatsAppEngine_1.waEngine.initialize();
            res.json({ message: 'Initialization started' });
        }
        else {
            res.json({ message: 'WhatsApp Engine is already initializing or connected.' });
        }
    });
}
function logout(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        yield WhatsAppEngine_1.waEngine.logout();
        res.json({ message: 'Logged out successfully' });
    });
}
