"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller_1 = require("./controller");
const middleware_1 = require("../auth/middleware");
const router = (0, express_1.Router)();
// Only Admins or authorized roles should control the WhatsApp engine
router.use(middleware_1.protect);
router.use((0, middleware_1.authorize)('ADMIN', 'SUPER_ADMIN'));
router.get('/status', controller_1.getStatus);
router.post('/init', controller_1.requestInitialization);
router.post('/logout', controller_1.logout);
exports.default = router;
