"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient({
    datasources: {
        db: {
            url: 'file:./dev.db',
        },
    },
});
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        const settings = yield prisma.systemSetting.findMany({
            where: { key: 'META_APP_ID' }
        });
        console.log('--- Database (server/dev.db) ---');
        console.log(JSON.stringify(settings, null, 2));
        const prismaSub = new client_1.PrismaClient({
            datasources: {
                db: {
                    url: 'file:./prisma/dev.db',
                },
            },
        });
        const settingsSub = yield prismaSub.systemSetting.findMany({
            where: { key: 'META_APP_ID' }
        });
        console.log('--- Database (server/prisma/dev.db) ---');
        console.log(JSON.stringify(settingsSub, null, 2));
    });
}
main()
    .catch((e) => {
    console.error(e);
    process.exit(1);
})
    .finally(() => __awaiter(void 0, void 0, void 0, function* () {
    yield prisma.$disconnect();
}));
