"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const axios_1 = __importDefault(require("axios"));
const prisma = new client_1.PrismaClient();
function checkMetaStatus() {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        console.log('--- Checking Meta App Diagnostic Status ---');
        try {
            // 1. Load credentials from DB
            const settings = yield prisma.systemSetting.findMany({
                where: { key: { in: ['META_APP_ID', 'META_APP_SECRET'] } }
            });
            const settingsMap = settings.reduce((acc, curr) => {
                acc[curr.key] = curr.value;
                return acc;
            }, {});
            const dbAppId = settingsMap['META_APP_ID'];
            const envAppId = process.env.META_APP_ID;
            const appId = dbAppId || envAppId;
            const dbAppSecret = settingsMap['META_APP_SECRET'];
            const envAppSecret = process.env.META_APP_SECRET;
            const appSecret = dbAppSecret || envAppSecret;
            console.log(`- App ID Source: ${dbAppId ? 'Database' : 'Environment'}`);
            if (!appId || appId.includes('placeholder')) {
                console.error('❌ Error: META_APP_ID is not configured or is a placeholder.');
                return;
            }
            console.log(`- App ID: ${appId}`);
            console.log(`- App Secret: ${appSecret ? '********' : '❌ MISSING'}`);
            // 2. Fetch App Status from Graph API
            // We use an App Access Token (client_id|client_secret)
            const appAccessToken = `${appId}|${appSecret}`;
            try {
                console.log(`- Fetching status for App ID ${appId} via Graph API...`);
                const response = yield axios_1.default.get(`https://graph.facebook.com/v21.0/${appId}`, {
                    params: {
                        access_token: appAccessToken,
                        fields: 'name,link,category'
                    }
                });
                console.log('✅ API Response Success!');
                console.log(JSON.stringify(response.data, null, 2));
                console.log('\n--- Status Summary ---');
                console.log(`Name: ${response.data.name}`);
                console.log(`Link: ${response.data.link}`);
                if (!response.data.privacy_url) {
                    console.warn('⚠️ Warning: Privacy Policy URL is missing. Meta requires this for it to be Live.');
                }
                else {
                    console.log(`Privacy URL: ${response.data.privacy_url}`);
                }
            }
            catch (apiError) {
                console.error('❌ Meta API Error:');
                const fbError = (_b = (_a = apiError.response) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.error;
                if (fbError) {
                    console.error(`  Code: ${fbError.code}`);
                    console.error(`  Message: ${fbError.message}`);
                    console.error(`  Type: ${fbError.type}`);
                    if (fbError.message.includes('updating additional details')) {
                        console.log('\n🚨 ACTION REQUIRED:');
                        console.log('This matches the error the user reported. Log in to developers.facebook.com and look for:');
                        console.log('1. Data Use Checkup alerts.');
                        console.log('2. App Review requests for requested permissions (ads_management, etc).');
                        console.log('3. Ensure the app is NOT in "Development" mode if use is external.');
                    }
                }
                else {
                    console.error(`  ${apiError.message}`);
                }
            }
        }
        catch (error) {
            console.error('Fatal Error during diagnostic:', error.message);
        }
        finally {
            yield prisma.$disconnect();
        }
    });
}
checkMetaStatus();
