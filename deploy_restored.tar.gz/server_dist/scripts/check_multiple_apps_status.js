"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const axios_1 = __importDefault(require("axios"));
const prisma = new client_1.PrismaClient();
function checkBothPossibleApps() {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const ids = ['574636601633519', '1707906853528856'];
        const secret = '672403621ff68d15be3d18cfa2e537e8';
        console.log('--- Multi-App Diagnostic ---');
        for (const id of ids) {
            try {
                console.log(`Checking App ID: ${id}...`);
                const response = yield axios_1.default.get(`https://graph.facebook.com/v21.0/${id}`, {
                    params: {
                        access_token: `${id}|${secret}`,
                        fields: 'name,link,category'
                    }
                });
                console.log(`✅ App ${id} is reachable:`, response.data.name);
            }
            catch (e) {
                console.error(`❌ App ${id} Status Error:`);
                const fbError = (_b = (_a = e.response) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.error;
                if (fbError) {
                    console.error(`  Code: ${fbError.code}`);
                    console.error(`  Message: ${fbError.message}`);
                }
                else {
                    console.error(`  Error: ${e.message}`);
                }
            }
            console.log('---');
        }
    });
}
checkBothPossibleApps();
