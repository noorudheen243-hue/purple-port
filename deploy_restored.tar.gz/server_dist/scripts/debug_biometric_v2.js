"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const prisma_1 = __importDefault(require("../utils/prisma"));
function debug() {
    return __awaiter(this, void 0, void 0, function* () {
        console.log("--- Biometric Connectivity Debug (v2) ---");
        try {
            const status = yield prisma_1.default.biometricDeviceStatus.findUnique({ where: { id: 'CURRENT' } });
            console.log("Current Database Record:");
            console.log(JSON.stringify(status, null, 2));
            if (status === null || status === void 0 ? void 0 : status.last_office_ip) {
                console.log(`✅ Office IP is registered: ${status.last_office_ip}`);
                console.log(`🕒 Registered at: ${status.last_office_registration}`);
            }
            else {
                console.log("❌ No Office IP registered yet.");
            }
            const deviceIp = '192.168.1.201';
            console.log(`\nLocal IP: ${deviceIp}`);
            // Dynamic Resolution Logic Test
            const targetIp = ((status === null || status === void 0 ? void 0 : status.last_office_ip) && status.last_office_ip !== 'unknown') ? status.last_office_ip : deviceIp;
            console.log(`Final Target IP for Sync: ${targetIp}`);
        }
        catch (e) {
            console.error("Debug failed:", e.message);
        }
        finally {
            process.exit();
        }
    });
}
debug();
