"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("../app"));
function listRoutes(stack, prefix = '') {
    const routes = [];
    stack.forEach((middleware) => {
        if (middleware.route) {
            // Route middleware
            const methods = Object.keys(middleware.route.methods).join(',').toUpperCase();
            routes.push(`${methods} ${prefix}${middleware.route.path}`);
        }
        else if (middleware.name === 'router') {
            // Router middleware
            const newPrefix = prefix + (middleware.regexp.source
                .replace('^\\', '')
                .replace('\\/?(?=\\/|$)', '')
                .replace(/\\\//g, '/') || '');
            routes.push(...listRoutes(middleware.handle.stack, newPrefix));
        }
    });
    return routes;
}
const allRoutes = listRoutes(app_1.default._router.stack);
console.log('Registered Routes:');
allRoutes.forEach(r => console.log(r));
const plannerRoutes = allRoutes.filter(r => r.includes('planner'));
if (plannerRoutes.length > 0) {
    console.log('\nSUCCESS: Planner routes are registered.');
    plannerRoutes.forEach(r => console.log(r));
}
else {
    console.log('\nFAILURE: Planner routes are NOT registered.');
}
