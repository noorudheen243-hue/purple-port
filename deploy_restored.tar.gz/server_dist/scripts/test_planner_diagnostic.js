"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const leave_planner_service_1 = require("../modules/attendance/leave-planner.service");
function test() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            console.log('Testing Holiday Service...');
            const holidays = yield leave_planner_service_1.LeavePlannerService.getHolidays(2026);
            console.log('Holidays found:', holidays.length);
            console.log('Testing Allocations Service...');
            const allocs = yield leave_planner_service_1.LeavePlannerService.getLeaveAllocations(2026);
            console.log('Allocations found:', allocs.length);
            console.log('SUCCESS: Service logic is working.');
        }
        catch (e) {
            console.error('FAILURE: Service logic failed.');
            console.error(e);
        }
    });
}
test();
