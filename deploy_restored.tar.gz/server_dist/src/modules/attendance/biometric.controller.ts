import { Request, Response } from 'express';
import { biometricControl } from './biometric.service';
import prisma from '../../utils/prisma';

export class BiometricController {

    // Get Device Info (Status, Serial, Capacities)
    static async getDeviceInfo(req: Request, res: Response) {
        try {
            const info = await biometricControl.getDeviceInfo();
            const status = await prisma.biometricDeviceStatus.findUnique({ where: { id: 'CURRENT' } });
            
            res.json({
                ...info,
                lastOfficeIp: status?.last_office_ip,
                lastOfficeRegistration: status?.last_office_registration
            });
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    // Get Users from Device
    static async getDeviceUsers(req: Request, res: Response) {
        try {
            const result = await biometricControl.getDeviceUsers();
            res.json(result);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    // Restart Device
    static async restartDevice(req: Request, res: Response) {
        try {
            const result = await biometricControl.restartDevice();
            res.json(result);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    // Sync Time
    static async syncTime(req: Request, res: Response) {
        try {
            const result = await biometricControl.syncDeviceTime();
            res.json(result);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    // Clear Logs
    static async clearLogs(req: Request, res: Response) {
        try {
            const result = await biometricControl.clearAttendanceLogs();
            res.json(result);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    // Unified Sync All Logs (Replaces syncLogs)
    static async syncAllLogs(req: Request, res: Response) {
        try {
            const { syncBiometrics } = require('./biometric.service');
            const result = await syncBiometrics('MANUAL');
            res.json(result);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    // Get Device Status from Persistent DB Table (Heartbeat Results)
    static async getDeviceStatus(req: Request, res: Response) {
        try {
            const status = await prisma.biometricDeviceStatus.findUnique({
                where: { id: 'CURRENT' }
            });
            res.json(status);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    // Get Sync History
    static async getSyncHistory(req: Request, res: Response) {
        try {
            const history = await prisma.biometricSyncLog.findMany({
                orderBy: { sync_time: 'desc' },
                take: 50
            });
            res.json(history);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    // Audit User Sync
    static async auditUserSync(req: Request, res: Response) {
        try {
            const result = await biometricControl.auditUserSync();
            res.json(result);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    // Add User to Device
    static async addUser(req: Request, res: Response) {
        try {
            // Expecting body: { uid, userId, name, role, cardno, password }
            const result = await biometricControl.setUserOnDevice(req.body);
            res.json(result);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    // Delete User from Device
    static async deleteUser(req: Request, res: Response) {
        try {
            const { userId } = req.body;
            if (!userId) throw new Error('User ID is required');
            const result = await biometricControl.deleteUserFromDevice(String(userId));
            res.json(result);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    // Get Unlinked Users
    static async getUnlinkedDeviceUsers(req: Request, res: Response) {
        try {
            const result = await biometricControl.getUnlinkedDeviceUsers();
            res.json(result);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    // Link Device User to Staff Profile
    static async linkDeviceUser(req: Request, res: Response) {
        try {
            const { deviceUserId, staffProfileId } = req.body;
            if (!deviceUserId || !staffProfileId) {
                throw new Error("Missing required fields: deviceUserId or staffProfileId.");
            }
            const result = await biometricControl.linkDeviceUser(String(deviceUserId), String(staffProfileId));
            res.json(result);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }
    // Upload Logs (Push from Remote Bridge -> DB)
    static async uploadLogs(req: Request, res: Response) {
        try {
            // Body: { logs: [], deviceId: string }
            const { logs } = req.body;
            if (!Array.isArray(logs)) throw new Error('Invalid logs format. Expected array.');

            // Re-use the processing logic
            const { processBiometricLogs } = require('./biometric.service');
            const result = await processBiometricLogs(logs);
            res.json(result);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    // Upload Users List (Push from Remote Bridge -> DB Cache)
    static async uploadUsersFromBridge(req: Request, res: Response) {
        try {
            const { users } = req.body;
            if (!Array.isArray(users)) throw new Error('Invalid users format. Expected array.');

            const result = await biometricControl.cacheDeviceUsers(users);
            res.json(result);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    // Register Office IP (Called from Client when in Office)
    static async registerOfficeIP(req: Request, res: Response) {
        try {
            // req.ip usually captures Public IP if proxy is configured
            const publicIp = req.ip || req.socket.remoteAddress || 'unknown';
            const cleanIp = publicIp.replace(/^.*:/, '');

            await prisma.biometricDeviceStatus.upsert({
                where: { id: 'CURRENT' },
                create: { 
                    id: 'CURRENT', 
                    status: 'ONLINE', 
                    last_heartbeat: new Date(), 
                    last_office_ip: cleanIp,
                    last_office_registration: new Date(),
                    updatedAt: new Date()
                },
                update: { 
                    last_office_ip: cleanIp,
                    last_office_registration: new Date(),
                    updatedAt: new Date()
                }
            });

            res.json({ message: 'Office IP registered successfully', ip: cleanIp });
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    // --- Bridge Bidirectional Endpoints ---

    static async bridgeHeartbeat(req: Request, res: Response) {
        try {
            const publicIp = req.ip || req.socket.remoteAddress || 'unknown';
            const cleanIp = publicIp.replace(/^.*:/, '');

            // Update Status with Heartbeat and IP
            await prisma.biometricDeviceStatus.upsert({
                where: { id: 'CURRENT' },
                create: { 
                    id: 'CURRENT', 
                    status: 'ONLINE', 
                    last_heartbeat: new Date(), 
                    last_office_ip: cleanIp,
                    last_office_registration: new Date(),
                    last_bridge_heartbeat: new Date(),
                    updatedAt: new Date()
                },
                update: { 
                    last_office_ip: cleanIp,
                    last_office_registration: new Date(),
                    last_bridge_heartbeat: new Date(),
                    updatedAt: new Date()
                }
            });

            // Fetch Pending Commands
            const commands = await biometricControl.getPendingCommands();
            res.json({ commands });
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }

    static async updateCommandResult(req: Request, res: Response) {
        try {
            const { id, status, result } = req.body;
            if (!id || !status) throw new Error("Missing ID or Status");

            const updated = await biometricControl.updateCommandStatus(id, status, result);
            res.json(updated);
        } catch (error: any) {
            res.status(500).json({ error: error.message });
        }
    }
}
