import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import prisma from '../../utils/prisma';
import { ROLES } from './roles';

if (!process.env.JWT_SECRET) {
    throw new Error('FATAL ERROR: JWT_SECRET environment variable is not defined.');
}
const JWT_SECRET = process.env.JWT_SECRET;


// Extend Express Request interface
declare global {
    namespace Express {
        interface Request {
            user?: {
                id: string;
                role: string;
                department: string;
                linked_client_id?: string | null;
            };
        }
    }
}

interface DecodedToken {
    userId: string;
    role: string;
}

export const protect = async (req: Request, res: Response, next: NextFunction) => {
    let token;

    // Check for token in cookies
    token = req.cookies.jwt;

    // Check for token in Authorization header
    if (!token && req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        token = req.headers.authorization.split(' ')[1];
    }

    if (token) {
        try {
            const decoded = jwt.verify(token, JWT_SECRET) as DecodedToken;

            const user = await prisma.user.findUnique({
                where: { id: decoded.userId },
                select: { id: true, role: true, department: true, linked_client_id: true }, // Select minimal fields
            });

            if (user) {
                req.user = {
                    id: user.id,
                    role: user.role,
                    department: user.department,
                    linked_client_id: user.linked_client_id
                };
                next();
            } else {
                res.status(401).json({ message: 'Not authorized, user not found' });
            }
        } catch (error) {
            console.error(error);
            res.status(401).json({ message: 'Not authorized, token failed' });
        }
    } else {
        res.status(401).json({ message: 'Not authorized, no token' });
    }
};

export const authorize = (...roles: string[]) => {
    return (req: Request, res: Response, next: NextFunction) => {
        // Developer Admin has access to everything
        // ADMIN usually has access to everything unless restricted logic is applied elsewhere
        if (req.user && (req.user.role === ROLES.DEVELOPER_ADMIN || roles.includes(req.user.role))) {
            next();
        } else {
            res.status(403).json({ message: 'Not authorized to access this route' });
        }
    };
};
