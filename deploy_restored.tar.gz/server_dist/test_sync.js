"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const metaAdsService_1 = require("./modules/marketing-tasks/services/metaAdsService");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        console.log("Starting debug sync for 1017260952339227...");
        const metaService = new metaAdsService_1.MetaAdsService();
        const accountId = '1017260952339227';
        // from Jan 1 2026 to Mar 31 2026
        const from = new Date('2026-01-01T00:00:00Z');
        const to = new Date('2026-03-31T23:59:59Z');
        try {
            const metrics = yield metaService.fetchAccountMetricsByCampaign(accountId, from, to);
            console.log(`Fetched ${metrics.length} daily metric records from Meta Insights.`);
            // Group by campaign
            const uniqueCampaigns = new Set(metrics.map(m => m.campaign_id));
            console.log(`Unique campaigns found in 2026 insights: ${uniqueCampaigns.size}`);
        }
        catch (e) {
            console.error("Error:", e.message);
        }
    });
}
run();
