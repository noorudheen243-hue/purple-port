"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const syncWorker_1 = require("./modules/marketing-tasks/sync/syncWorker");
const client_1 = require("@prisma/client");
function runSync() {
    return __awaiter(this, void 0, void 0, function* () {
        console.log('Starting Manual Sync Logic Test...');
        // Sync last 30 days to be sure we get some data
        yield syncWorker_1.MarketingSyncWorker.syncAllActiveCampaigns(30);
        console.log('Sync completed.');
        const prisma = new client_1.PrismaClient();
        const count = yield prisma.marketingMetric.count();
        console.log('Total Marketing Metrics after sync:', count);
        const campaigns = yield prisma.marketingCampaign.findMany({
            where: { platform: 'meta' },
            include: { marketingMetrics: { take: 1, orderBy: { date: 'desc' } } }
        });
        campaigns.forEach(c => {
            console.log(`Campaign: ${c.name} - Metrics: ${c.marketingMetrics.length}`);
        });
    });
}
runSync().catch(console.error);
