"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        console.log('--- SYNC LOGS ---');
        const logs = yield prisma.marketingSyncLog.findMany({
            orderBy: { startedAt: 'desc' },
            take: 5
        });
        console.log(JSON.stringify(logs, null, 2));
        console.log('\n--- CAMPAIGN COUNT ---');
        const campaignCount = yield prisma.marketingCampaign.count();
        console.log(`Total Campaigns: ${campaignCount}`);
        console.log('\n--- LATEST CAMPAIGNS ---');
        const campaigns = yield prisma.marketingCampaign.findMany({
            orderBy: { createdAt: 'desc' },
            take: 5,
            include: {
                marketingMetrics: {
                    orderBy: { date: 'desc' },
                    take: 1
                }
            }
        });
        console.log(JSON.stringify(campaigns, null, 2));
    });
}
main()
    .catch(e => console.error(e))
    .finally(() => __awaiter(void 0, void 0, void 0, function* () {
    yield prisma.$disconnect();
}));
