"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const syncWorker_1 = require("./modules/marketing-tasks/sync/syncWorker");
const prisma = new client_1.PrismaClient();
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        console.log('--- STARTING MANUAL SYNC TEST ---');
        // Sync for the last 7 days to ensure we get some data
        yield syncWorker_1.MarketingSyncWorker.syncAllActiveCampaigns(7);
        console.log('--- SYNC COMPLETED ---');
        console.log('\n--- VERIFYING DATA ---');
        const campaigns = yield prisma.marketingCampaign.findMany({
            where: { platform: 'meta' },
            include: {
                marketingMetrics: {
                    orderBy: { date: 'desc' },
                    take: 1
                }
            },
            take: 10
        });
        console.log(JSON.stringify(campaigns, null, 2));
    });
}
main()
    .catch(e => console.error(e))
    .finally(() => __awaiter(void 0, void 0, void 0, function* () {
    yield prisma.$disconnect();
}));
