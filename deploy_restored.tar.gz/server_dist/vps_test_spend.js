"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const prisma_1 = __importDefault(require("./utils/prisma"));
function checkSpend() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const accounts = yield prisma_1.default.marketingAccount.findMany();
            console.log("Found accounts:", accounts.map(a => a.externalAccountId).join(', '));
            let account = accounts.find(a => a.externalAccountId.includes('1017260952339227'));
            if (!account) {
                console.log("Account 1017260952339227 not found manually either.");
                return;
            }
            const activeCampaigns = yield prisma_1.default.marketingCampaign.findMany({
                where: {
                    clientId: account.clientId,
                    platform: 'meta',
                    status: 'ACTIVE'
                }
            });
            console.log(`Found ${activeCampaigns.length} campaigns with status=ACTIVE in DB.`);
            let totalSpend = 0;
            for (const camp of activeCampaigns) {
                const metrics = yield prisma_1.default.marketingMetric.findMany({
                    where: { campaignId: camp.id }
                });
                const spend = metrics.reduce((sum, m) => sum + (m.spend || 0), 0);
                totalSpend += spend;
                if (spend > 0) {
                    console.log(`- Campaign: ${camp.name} | Status: ${camp.status} | Spend: ${spend}`);
                }
            }
            console.log(`Total Spend for ACTIVE campaigns: ${totalSpend}`);
        }
        catch (e) {
            console.error("Error:", e.message);
        }
    });
}
checkSpend();
